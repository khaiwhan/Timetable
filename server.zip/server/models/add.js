var db = require('../connectdb'); //reference of connectdb.js
var Add = {

    //add student groups
    addStudentGroups: async function (data, callback) {
        var selectSQL = `INSERT INTO student_groups (student_groups_name) VALUES (?);`;
        var student_groups_name = data.student_groups_name;
        console.log(data)
        await db.query(selectSQL, [student_groups_name], callback);

        var input = student_groups_name;
        var output = input.substring(0, 2);
        console.log("output", output);
        if (output === '53' || output === '54' || output === '55' || output === '56' || output === '57') {
            var course_id = '1';
            console.log("course_id", course_id);
        }
        else if (output === '58' || output === '59' || output === '60' || output === '61' || output === '62') {
            var course_id = '2';
            console.log("course_id", course_id);
        }
        else if (output === '63' || output === '64' || output === '65' || output === '66' || output === '67') {
            var course_id = '3';
            console.log("course_id", course_id);
        }
        else if (output === '68' || output === '69' || output === '70' || output === '71' || output === '72') {
            var course_id = '4';
            console.log("course_id", course_id);
        }
        else {
            console.log("err");
        }

        var SQL = `INSERT INTO course_student_groups (course_id, student_groups_id)
        SELECT '${course_id}',student_groups.student_groups_id
        FROM student_groups
        WHERE student_groups.student_groups_name = '${student_groups_name}';`
        await db.query(SQL);
    },

    //add room
    addRoom: function (data, callback) {
        var selectSQL = 'INSERT INTO `room`(`room_id`, `room_amount`) VALUES (?,?);';
        var room_id = data.room_id;
        var room_amount = data.room_amount;
        return db.query(selectSQL, [room_id, room_amount], callback);
    },

    //add subject
    addSubject: async function (data, course_id, callback) {
        var subject_id = data.subject_id;
        var subject_name = data.subject_name;
        var subject_unit = data.subject_unit;
        var required_subject = data.required_subject;
        console.log(data);
        var selectSQL = `INSERT INTO subject (subject_id, subject_name, subject_unit, required_subject )
        VALUES ('${subject_id}','${subject_name}','${subject_unit}','${required_subject}');`;
        var SQL = `INSERT INTO course_subject ( course_id, subject_id) VALUES ('${course_id}','${subject_id}');`;
        await db.query(selectSQL, [subject_id, subject_id, subject_unit, required_subject], callback);
        await db.query(SQL, [course_id, subject_id]);
    },

    //add rm21
    addRM21: async function (data, callback) {
        var subject_id = data.subject_id;
        var student_groups_id = data.student_groups_id;
        var term_id = data.term_id;
        var year_id = data.year_id;
        var selectSQL = `INSERT INTO rm21(subject_id, student_groups_id, term_id, year_id) VALUES ('${subject_id}','${student_groups_id}','${term_id}','${year_id}')`;
        var SQL = `INSERT INTO view_timetable(subject_id, student_groups_id, term_id, year_id) VALUES ('${subject_id}','${student_groups_id}','${term_id}','${year_id}');`;
        await db.query(selectSQL, [subject_id, student_groups_id, term_id, year_id], callback);
        await db.query(SQL, [subject_id, student_groups_id, term_id, year_id]);
    },

    //add subject teacher
    addSubjectTeacher: function (data, callback) {
        var selectSQL = `INSERT INTO subject_teacher(subject_id, teacher_t, teacher_l1, teacher_l2, teacher_l3, teacher_l4) VALUES (?,?,?,?,?,?);`;
        var subject_id = data.subject_id;
        var teacher_t = data.teacher_t;
        var teacher_l1 = data.teacher_l1;
        var teacher_l2 = data.teacher_l2;
        var teacher_l3 = data.teacher_l3;
        var teacher_l4 = data.teacher_l4;
        console.log(data)
        return db.query(selectSQL, [subject_id, teacher_t, teacher_l1, teacher_l2, teacher_l3, teacher_l4], callback);
    },

    //add teacher 7x13
    addTeacher7x13: async function (data, callback) {
        var teacher_id = data.teacher_id;
        var year_id = data.year_id;
        var term_id = data.term_id;
        var SQL1 = `INSERT INTO teacher_7x13 (teacher_id, year_id, term_id, day_id) VALUES('${teacher_id}','${year_id}','${term_id}',1);`
        var SQL2 = `INSERT INTO teacher_7x13 (teacher_id, year_id, term_id, day_id) VALUES('${teacher_id}','${year_id}','${term_id}',2);`
        var SQL3 = `INSERT INTO teacher_7x13 (teacher_id, year_id, term_id, day_id) VALUES('${teacher_id}','${year_id}','${term_id}',3);`
        var SQL4 = `INSERT INTO teacher_7x13 (teacher_id, year_id, term_id, day_id) VALUES('${teacher_id}','${year_id}','${term_id}',4);`
        var SQL5 = `INSERT INTO teacher_7x13 (teacher_id, year_id, term_id, day_id) VALUES('${teacher_id}','${year_id}','${term_id}',5);`
        var SQL6 = `INSERT INTO teacher_7x13 (teacher_id, year_id, term_id, day_id) VALUES('${teacher_id}','${year_id}','${term_id}',6);`
        var SQL7 = `INSERT INTO teacher_7x13 (teacher_id, year_id, term_id, day_id) VALUES('${teacher_id}','${year_id}','${term_id}',7);`
        await db.query(SQL1, [teacher_id, year_id, term_id], callback);
        await db.query(SQL2, [teacher_id, year_id, term_id]);
        await db.query(SQL3, [teacher_id, year_id, term_id]);
        await db.query(SQL4, [teacher_id, year_id, term_id]);
        await db.query(SQL5, [teacher_id, year_id, term_id]);
        await db.query(SQL6, [teacher_id, year_id, term_id]);
        await db.query(SQL7, [teacher_id, year_id, term_id]);
    },

    //add student groups 7x13
    addStudentGroups7x13: async function (data, callback) {
        var student_groups_id = data.student_groups_id;
        var year_id = data.year_id;
        var term_id = data.term_id;
        var SQL1 = `INSERT INTO student_groups_7x13 (student_groups_id, year_id, term_id, day_id) VALUES('${student_groups_id}','${year_id}','${term_id}',1);`
        var SQL2 = `INSERT INTO student_groups_7x13 (student_groups_id, year_id, term_id, day_id) VALUES('${student_groups_id}','${year_id}','${term_id}',2);`
        var SQL3 = `INSERT INTO student_groups_7x13 (student_groups_id, year_id, term_id, day_id) VALUES('${student_groups_id}','${year_id}','${term_id}',3);`
        var SQL4 = `INSERT INTO student_groups_7x13 (student_groups_id, year_id, term_id, day_id) VALUES('${student_groups_id}','${year_id}','${term_id}',4);`
        var SQL5 = `INSERT INTO student_groups_7x13 (student_groups_id, year_id, term_id, day_id) VALUES('${student_groups_id}','${year_id}','${term_id}',5);`
        var SQL6 = `INSERT INTO student_groups_7x13 (student_groups_id, year_id, term_id, day_id) VALUES('${student_groups_id}','${year_id}','${term_id}',6);`
        var SQL7 = `INSERT INTO student_groups_7x13 (student_groups_id, year_id, term_id, day_id) VALUES('${student_groups_id}','${year_id}','${term_id}',7);`
        await db.query(SQL1, [student_groups_id, year_id, term_id], callback);
        await db.query(SQL2, [student_groups_id, year_id, term_id]);
        await db.query(SQL3, [student_groups_id, year_id, term_id]);
        await db.query(SQL4, [student_groups_id, year_id, term_id]);
        await db.query(SQL5, [student_groups_id, year_id, term_id]);
        await db.query(SQL6, [student_groups_id, year_id, term_id]);
        await db.query(SQL7, [student_groups_id, year_id, term_id]);
    },

    //add room 7x13
    addRoom7x13: async function (data, callback) {
        var room_id = data.room_id;
        var year_id = data.year_id;
        var term_id = data.term_id;
        var SQL1 = `INSERT INTO room_7x13 (room_id, year_id, term_id, day_id) VALUES('${room_id}','${year_id}','${term_id}',1);`
        var SQL2 = `INSERT INTO room_7x13 (room_id, year_id, term_id, day_id) VALUES('${room_id}','${year_id}','${term_id}',2);`
        var SQL3 = `INSERT INTO room_7x13 (room_id, year_id, term_id, day_id) VALUES('${room_id}','${year_id}','${term_id}',3);`
        var SQL4 = `INSERT INTO room_7x13 (room_id, year_id, term_id, day_id) VALUES('${room_id}','${year_id}','${term_id}',4);`
        var SQL5 = `INSERT INTO room_7x13 (room_id, year_id, term_id, day_id) VALUES('${room_id}','${year_id}','${term_id}',5);`
        var SQL6 = `INSERT INTO room_7x13 (room_id, year_id, term_id, day_id) VALUES('${room_id}','${year_id}','${term_id}',6);`
        var SQL7 = `INSERT INTO room_7x13 (room_id, year_id, term_id, day_id) VALUES('${room_id}','${year_id}','${term_id}',7);`
        await db.query(SQL1, [room_id, year_id, term_id], callback);
        await db.query(SQL2, [room_id, year_id, term_id]);
        await db.query(SQL3, [room_id, year_id, term_id]);
        await db.query(SQL4, [room_id, year_id, term_id]);
        await db.query(SQL5, [room_id, year_id, term_id]);
        await db.query(SQL6, [room_id, year_id, term_id]);
        await db.query(SQL7, [room_id, year_id, term_id]);
    },

}; module.exports = Add;