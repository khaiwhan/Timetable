var db = require('../connectdb'); //reference of connectdb.js
var Update = {

    //update student
    updateStudent: function (data, callback) {
        var selectSQL = 'UPDATE student SET student_password=?, student_name=?, student_groups_id=? WHERE student_id=?';
        var student_password = data.student_update_password;
        var student_name = data.student_update_name;
        var student_groups_id = data.student_update_groups_id;
        var student_id = data.student_update_id;
        console.log(data);
        return db.query(selectSQL, [student_password, student_name, student_groups_id, student_id], callback);
    },

    //update teacher
    updateTeacher: function (data, callback) {
        var selectSQL = `UPDATE teacher
          SET teacher_password=?, teacher_name=?, teacher_website=?, teacher_email=?, teacher_phone=?
          WHERE teacher.teacher_id=?`;
        var teacher_password = data.teacher_update_password;
        var teacher_name = data.teacher_update_name;
        var teacher_website = data.teacher_update_website;
        var teacher_email = data.teacher_update_email;
        var teacher_phone = data.teacher_update_phone;
        var teacher_id = data.teacher_update_id;
        console.log(data);
        return db.query(selectSQL, [teacher_password, teacher_name, teacher_website, teacher_email, teacher_phone, teacher_id], callback);
    },

    //update Subject
    updateSubject: async function (data, course_id, callback) {
        var subject_name = data.subject_update_name;
        var subject_unit = data.subject_update_unit;
        var required_subject = data.required_update_subject;
        var subject_id = data.subject_update_id;
        console.log(data);
        var selectSQL = `UPDATE subject SET subject_name = '${subject_name}', subject_unit = '${subject_unit}', required_subject = '${required_subject}' WHERE subject_id = '${subject_id}';`
        var SQL = `UPDATE course_subject SET course_id = '${course_id}' WHERE subject_id = '${subject_id}';`
        await db.query(selectSQL, [subject_id, subject_id, subject_unit, required_subject], callback);
        await db.query(SQL, [course_id, subject_id]);
    },

    //update room
    updateRoom: function (data, callback) {
        var selectSQL = 'UPDATE room SET room_amount=?WHERE room_id=?';
        var room_amount = data.room_update_amount;
        var room_id = data.room_update_id;
        return db.query(selectSQL, [room_amount, room_id], callback);
    },

    // update teacher 7x13
    updateTeacher7x13: function (data, callback) {
        var teacher_id = data.teacher_id;
        var year_id = data.year_id;
        var term_id = data.term_id;
        var day_id = data.day_id;
        var time1 = data.time1;
        var time2 = data.time2;
        var time3 = data.time3;
        var time4 = data.time4;
        var time5 = data.time5;
        var time6 = data.time6;
        var time7 = data.time7;
        var time8 = data.time8;
        var time9 = data.time9;
        var time10 = data.time10;
        var time11 = data.time11;
        var time12 = data.time12;
        var time13 = data.time13;
        var SQL = `UPDATE teacher_7x13 SET time1 = '${time1}', time2 = '${time2}', time3 = '${time3}', time4 = '${time4}', time5 = '${time5}', time6 = '${time6}', time7 = '${time7}', time8 = '${time8}', time9 = '${time9}', time10 = '${time10}', time11 = '${time11}', time12 = '${time12}', time13 = '${time13}'
        WHERE teacher_id = '${teacher_id}' AND year_id = '${year_id}' AND term_id = '${term_id}' AND day_id = '${day_id}'`;
        return db.query(SQL, [time1, time2, time3, time4, time5, time6, time7, time8, time9, time10, time11, time12, time13, teacher_id, year_id, term_id, day_id], callback);
    },

    // update student groups 7x13
    updateStudentGroups7x13: function (data, callback) {
        var student_groups_id = data.student_groups_id;
        var year_id = data.year_id;
        var term_id = data.term_id;
        var day_id = data.day_id;
        var time1 = data.time1;
        var time2 = data.time2;
        var time3 = data.time3;
        var time4 = data.time4;
        var time5 = data.time5;
        var time6 = data.time6;
        var time7 = data.time7;
        var time8 = data.time8;
        var time9 = data.time9;
        var time10 = data.time10;
        var time11 = data.time11;
        var time12 = data.time12;
        var time13 = data.time13;
        var SQL = `UPDATE student_groups_7x13 SET time1 = '${time1}', time2 = '${time2}', time3 = '${time3}', time4 = '${time4}', time5 = '${time5}', time6 = '${time6}', time7 = '${time7}', time8 = '${time8}', time9 = '${time9}', time10 = '${time10}', time11 = '${time11}', time12 = '${time12}', time13 = '${time13}'
        WHERE student_groups_id = '${student_groups_id}' AND year_id = '${year_id}' AND term_id = '${term_id}' AND day_id = '${day_id}'`;
        return db.query(SQL, [time1, time2, time3, time4, time5, time6, time7, time8, time9, time10, time11, time12, time13, student_groups_id, year_id, term_id, day_id], callback);
    },

    // update room 7x13
    updateRoom7x13: function (data, callback) {
        var room_id = data.room_id;
        var year_id = data.year_id;
        var term_id = data.term_id;
        var day_id = data.day_id;
        var time1 = data.time1;
        var time2 = data.time2;
        var time3 = data.time3;
        var time4 = data.time4;
        var time5 = data.time5;
        var time6 = data.time6;
        var time7 = data.time7;
        var time8 = data.time8;
        var time9 = data.time9;
        var time10 = data.time10;
        var time11 = data.time11;
        var time12 = data.time12;
        var time13 = data.time13;
        var SQL = `UPDATE room_7x13 SET time1 = '${time1}', time2 = '${time2}', time3 = '${time3}', time4 = '${time4}', time5 = '${time5}', time6 = '${time6}', time7 = '${time7}', time8 = '${time8}', time9 = '${time9}', time10 = '${time10}', time11 = '${time11}', time12 = '${time12}', time13 = '${time13}'
        WHERE room_id = '${room_id}' AND year_id = '${year_id}' AND term_id = '${term_id}' AND day_id = '${day_id}'`;
        return db.query(SQL, [time1, time2, time3, time4, time5, time6, time7, time8, time9, time10, time11, time12, time13, room_id, year_id, term_id, day_id], callback);
    },

}; module.exports = Update;