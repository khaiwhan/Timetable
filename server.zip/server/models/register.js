var db = require('../connectdb'); //reference of connectdb.js
var Register = {

//register student
registerStudent: function (data, callback) {
    var selectSQL = 'INSERT INTO `student`(`student_id`, `student_password`, `student_name`, `student_groups_id`) VALUES (?,?,?,?)';
    var student_id = data.student_id;
    var student_password = data.student_password;
    var student_name = data.student_name;
    var student_groups_id = data.student_groups_id;
    console.log(data);
    return db.query(selectSQL, [student_id, student_password, student_name, student_groups_id], callback);
},

//register teacher
registerTeacher: function (data, callback) {
    var selectSQL = 'INSERT INTO `teacher`(`teacher_id`, `teacher_password`, `teacher_name`, `teacher_website`, `teacher_email`, `teacher_phone`) VALUES (?,?,?,?,?,?)';
    var teacher_id = data.teacher_id;
    var teacher_password = data.teacher_password;
    var teacher_name = data.teacher_name;
    var teacher_website = data.teacher_website;
    var teacher_email = data.teacher_email;
    var teacher_phone = data.teacher_phone;
    console.log(data);
    return db.query(selectSQL, [teacher_id, teacher_password, teacher_name, teacher_website, teacher_email, teacher_phone], callback);
}

}; module.exports = Register;