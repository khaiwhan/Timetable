var db = require('../connectdb'); //reference of connectdb.js
var Login = {
    //login admin
    loginAdmin: function (data, callback) {
        var selectSQL = 'Select admin_id, admin_name from admin where admin_id=? AND admin_password=?';
        var admin_id = data.admin_id;
        var admin_password = data.admin_password;
        console.log(data);
        return db.query(selectSQL, [admin_id, admin_password], callback);

    },

    //login student
    loginStudent: function (data, callback) {
        var selectSQL = `SELECT
        student.student_id,
        student.student_password,
        student.student_name,
        student.student_groups_id,
        student_groups.student_groups_name
        FROM student
        LEFT JOIN student_groups ON student.student_groups_id = student_groups.student_groups_id
        where student_id=? AND student_password=?`;
        var student_id = data.student_id;
        var student_password = data.student_password;
        console.log(data);
        return db.query(selectSQL, [student_id, student_password], callback);
    },

    //login teacher
    loginTeacher: function (data, callback) {
        var selectSQL = 'Select teacher_id,teacher_name from teacher where teacher_id=? AND teacher_password=?';
        var teacher_id = data.teacher_id;
        var teacher_password = data.teacher_password;
        console.log(data);
        return db.query(selectSQL, [teacher_id, teacher_password], callback);
    },

}; module.exports = Login;