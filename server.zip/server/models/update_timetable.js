var db = require('../connectdb'); //reference of connectdb.js
var Update7x13 = {

    //select timetable student_groups , teacher
    selectTimetable: async function (data, callback) {
        var cs_time1; var cs_time2; var cs_time3;
        var cs_time4; var cs_time5; var cs_time6;
        var cs_time7; var cs_time8; var cs_time9;
        var cs_time10; var cs_time11; var cs_time12;
        var cs_time13;

        var ct_time1; var ct_time2; var ct_time3;
        var ct_time4; var ct_time5; var ct_time6;
        var ct_time7; var ct_time8; var ct_time9;
        var ct_time10; var ct_time11; var ct_time12;
        var ct_time13;

        for (let i = 0; i <= 6; i++) {

            if (data.student[i].time1) { cs_time1 = 1; } else { cs_time1 = 0; }
            if (data.student[i].time2) { cs_time2 = 1; } else { cs_time2 = 0; }
            if (data.student[i].time3) { cs_time3 = 1; } else { cs_time3 = 0; }
            if (data.student[i].time4) { cs_time4 = 1; } else { cs_time4 = 0; }
            if (data.student[i].time5) { cs_time5 = 1; } else { cs_time5 = 0; }
            if (data.student[i].time6) { cs_time6 = 1; } else { cs_time6 = 0; }
            if (data.student[i].time7) { cs_time7 = 1; } else { cs_time7 = 0; }
            if (data.student[i].time8) { cs_time8 = 1; } else { cs_time8 = 0; }
            if (data.student[i].time9) { cs_time9 = 1; } else { cs_time9 = 0; }
            if (data.student[i].time10) { cs_time10 = 1; } else { cs_time10 = 0; }
            if (data.student[i].time11) { cs_time11 = 1; } else { cs_time11 = 0; }
            if (data.student[i].time12) { cs_time12 = 1; } else { cs_time12 = 0; }
            if (data.student[i].time13) { cs_time13 = 1; } else { cs_time13 = 0; }

            if (data.teacher[i].time1) { ct_time1 = 1; } else { ct_time1 = 0; }
            if (data.teacher[i].time2) { ct_time2 = 1; } else { ct_time2 = 0; }
            if (data.teacher[i].time3) { ct_time3 = 1; } else { ct_time3 = 0; }
            if (data.teacher[i].time4) { ct_time4 = 1; } else { ct_time4 = 0; }
            if (data.teacher[i].time5) { ct_time5 = 1; } else { ct_time5 = 0; }
            if (data.teacher[i].time6) { ct_time6 = 1; } else { ct_time6 = 0; }
            if (data.teacher[i].time7) { ct_time7 = 1; } else { ct_time7 = 0; }
            if (data.teacher[i].time8) { ct_time8 = 1; } else { ct_time8 = 0; }
            if (data.teacher[i].time9) { ct_time9 = 1; } else { ct_time9 = 0; }
            if (data.teacher[i].time10) { ct_time10 = 1; } else { ct_time10 = 0; }
            if (data.teacher[i].time11) { ct_time11 = 1; } else { ct_time11 = 0; }
            if (data.teacher[i].time12) { ct_time12 = 1; } else { ct_time12 = 0; }
            if (data.teacher[i].time13) { ct_time13 = 1; } else { ct_time13 = 0; }

            var day_id = parseInt([i]) + 1;

            var ns_time1 = parseInt(cs_time1);
            var ns_time2 = parseInt(cs_time2);
            var ns_time3 = parseInt(cs_time3);
            var ns_time4 = parseInt(cs_time4);
            var ns_time5 = parseInt(cs_time5);
            var ns_time6 = parseInt(cs_time6);
            var ns_time7 = parseInt(cs_time7);
            var ns_time8 = parseInt(cs_time8);
            var ns_time9 = parseInt(cs_time9);
            var ns_time10 = parseInt(cs_time10);
            var ns_time11 = parseInt(cs_time11);
            var ns_time12 = parseInt(cs_time12);
            var ns_time13 = parseInt(cs_time13);

            var nt_time1 = parseInt(ct_time1);
            var nt_time2 = parseInt(ct_time2);
            var nt_time3 = parseInt(ct_time3);
            var nt_time4 = parseInt(ct_time4);
            var nt_time5 = parseInt(ct_time5);
            var nt_time6 = parseInt(ct_time6);
            var nt_time7 = parseInt(ct_time7);
            var nt_time8 = parseInt(ct_time8);
            var nt_time9 = parseInt(ct_time9);
            var nt_time10 = parseInt(ct_time10);
            var nt_time11 = parseInt(ct_time11);
            var nt_time12 = parseInt(ct_time12);
            var nt_time13 = parseInt(ct_time13);

            var d_time1 = ns_time1 || nt_time1;
            var d_time2 = ns_time2 || nt_time2;
            var d_time3 = ns_time3 || nt_time3;
            var d_time4 = ns_time4 || nt_time4;
            var d_time5 = ns_time5 || nt_time5;
            var d_time6 = ns_time6 || nt_time6;
            var d_time7 = ns_time7 || nt_time7;
            var d_time8 = ns_time8 || nt_time8;
            var d_time9 = ns_time9 || nt_time9;
            var d_time10 = ns_time10 || nt_time10;
            var d_time11 = ns_time11 || nt_time11;
            var d_time12 = ns_time12 || nt_time12;
            var d_time13 = ns_time13 || nt_time13;

            if (d_time1 == 0) { d_time1 = ""; } else { if (ns_time1 == 1) { d_time1 = data.student[i].time1 } else { d_time1 = "Busy" }; }
            if (d_time2 == 0) { d_time2 = ""; } else { if (ns_time2 == 1) { d_time2 = data.student[i].time2 } else { d_time2 = "Busy" }; }
            if (d_time3 == 0) { d_time3 = ""; } else { if (ns_time3 == 1) { d_time3 = data.student[i].time3 } else { d_time3 = "Busy" }; }
            if (d_time4 == 0) { d_time4 = ""; } else { if (ns_time4 == 1) { d_time4 = data.student[i].time4 } else { d_time4 = "Busy" }; }
            if (d_time5 == 0) { d_time5 = ""; } else { if (ns_time5 == 1) { d_time5 = data.student[i].time5 } else { d_time5 = "Busy" }; }
            if (d_time6 == 0) { d_time6 = ""; } else { if (ns_time6 == 1) { d_time6 = data.student[i].time6 } else { d_time6 = "Busy" }; }
            if (d_time7 == 0) { d_time7 = ""; } else { if (ns_time7 == 1) { d_time7 = data.student[i].time7 } else { d_time7 = "Busy" }; }
            if (d_time8 == 0) { d_time8 = ""; } else { if (ns_time8 == 1) { d_time8 = data.student[i].time8 } else { d_time8 = "Busy" }; }
            if (d_time9 == 0) { d_time9 = ""; } else { if (ns_time9 == 1) { d_time9 = data.student[i].time9 } else { d_time9 = "Busy" }; }
            if (d_time10 == 0) { d_time10 = ""; } else { if (ns_time10 == 1) { d_time10 = data.student[i].time10 } else { d_time10 = "Busy" }; }
            if (d_time11 == 0) { d_time11 = ""; } else { if (ns_time11 == 1) { d_time11 = data.student[i].time11 } else { d_time11 = "Busy" }; }
            if (d_time12 == 0) { d_time12 = ""; } else { if (ns_time12 == 1) { d_time12 = data.student[i].time12 } else { d_time12 = "Busy" }; }
            if (d_time13 == 0) { d_time13 = ""; } else { if (ns_time13 == 1) { d_time13 = data.student[i].time13 } else { d_time13 = "Busy" }; }

            var SQL = `UPDATE display_timetable SET time1 = '${d_time1}', time2 = '${d_time2}', time3 = '${d_time3}', time4 = '${d_time4}', time5 = '${d_time5}', time6 = '${d_time6}', time7 = '${d_time7}', time8 = '${d_time8}', time9 = '${d_time9}', time10 = '${d_time10}', time11 = '${d_time11}', time12 = '${d_time12}', time13 = '${d_time13}'
            WHERE day_id = '${day_id}'`;
            await db.query(SQL, [d_time1, d_time2, d_time3, d_time4, d_time5, d_time6, d_time7, d_time8, d_time9, d_time10, d_time11, d_time12, d_time13, day_id]);
        }
        var selectSQL = `SELECT day.day_name,
        display_timetable.time1, display_timetable.time2, display_timetable.time3, display_timetable.time4,
        display_timetable.time5, display_timetable.time6, display_timetable.time7, display_timetable.time8,
        display_timetable.time9, display_timetable.time10, display_timetable.time11, display_timetable.time12,
        display_timetable.time13
        FROM day
        LEFT JOIN display_timetable ON display_timetable.day_id = day.day_id
        ORDER BY display_timetable.day_id`;
        await db.query(selectSQL, callback);
    },

    //select timetable student_groups , teacher , room
    selectTimetableR: async function (data, callback) {
        var cs_time1; var cs_time2; var cs_time3;
        var cs_time4; var cs_time5; var cs_time6;
        var cs_time7; var cs_time8; var cs_time9;
        var cs_time10; var cs_time11; var cs_time12;
        var cs_time13;

        var ct_time1; var ct_time2; var ct_time3;
        var ct_time4; var ct_time5; var ct_time6;
        var ct_time7; var ct_time8; var ct_time9;
        var ct_time10; var ct_time11; var ct_time12;
        var ct_time13;

        var cr_time1; var cr_time2; var cr_time3;
        var cr_time4; var cr_time5; var cr_time6;
        var cr_time7; var cr_time8; var cr_time9;
        var cr_time10; var cr_time11; var cr_time12;
        var cr_time13;


        for (let i = 0; i <= 6; i++) {

            if (data.student[i].time1) { cs_time1 = 1; } else { cs_time1 = 0; }
            if (data.student[i].time2) { cs_time2 = 1; } else { cs_time2 = 0; }
            if (data.student[i].time3) { cs_time3 = 1; } else { cs_time3 = 0; }
            if (data.student[i].time4) { cs_time4 = 1; } else { cs_time4 = 0; }
            if (data.student[i].time5) { cs_time5 = 1; } else { cs_time5 = 0; }
            if (data.student[i].time6) { cs_time6 = 1; } else { cs_time6 = 0; }
            if (data.student[i].time7) { cs_time7 = 1; } else { cs_time7 = 0; }
            if (data.student[i].time8) { cs_time8 = 1; } else { cs_time8 = 0; }
            if (data.student[i].time9) { cs_time9 = 1; } else { cs_time9 = 0; }
            if (data.student[i].time10) { cs_time10 = 1; } else { cs_time10 = 0; }
            if (data.student[i].time11) { cs_time11 = 1; } else { cs_time11 = 0; }
            if (data.student[i].time12) { cs_time12 = 1; } else { cs_time12 = 0; }
            if (data.student[i].time13) { cs_time13 = 1; } else { cs_time13 = 0; }

            if (data.teacher[i].time1) { ct_time1 = 1; } else { ct_time1 = 0; }
            if (data.teacher[i].time2) { ct_time2 = 1; } else { ct_time2 = 0; }
            if (data.teacher[i].time3) { ct_time3 = 1; } else { ct_time3 = 0; }
            if (data.teacher[i].time4) { ct_time4 = 1; } else { ct_time4 = 0; }
            if (data.teacher[i].time5) { ct_time5 = 1; } else { ct_time5 = 0; }
            if (data.teacher[i].time6) { ct_time6 = 1; } else { ct_time6 = 0; }
            if (data.teacher[i].time7) { ct_time7 = 1; } else { ct_time7 = 0; }
            if (data.teacher[i].time8) { ct_time8 = 1; } else { ct_time8 = 0; }
            if (data.teacher[i].time9) { ct_time9 = 1; } else { ct_time9 = 0; }
            if (data.teacher[i].time10) { ct_time10 = 1; } else { ct_time10 = 0; }
            if (data.teacher[i].time11) { ct_time11 = 1; } else { ct_time11 = 0; }
            if (data.teacher[i].time12) { ct_time12 = 1; } else { ct_time12 = 0; }
            if (data.teacher[i].time13) { ct_time13 = 1; } else { ct_time13 = 0; }

            if (data.room[i].time1) { cr_time1 = 1; } else { cr_time1 = 0; }
            if (data.room[i].time2) { cr_time2 = 1; } else { cr_time2 = 0; }
            if (data.room[i].time3) { cr_time3 = 1; } else { cr_time3 = 0; }
            if (data.room[i].time4) { cr_time4 = 1; } else { cr_time4 = 0; }
            if (data.room[i].time5) { cr_time5 = 1; } else { cr_time5 = 0; }
            if (data.room[i].time6) { cr_time6 = 1; } else { cr_time6 = 0; }
            if (data.room[i].time7) { cr_time7 = 1; } else { cr_time7 = 0; }
            if (data.room[i].time8) { cr_time8 = 1; } else { cr_time8 = 0; }
            if (data.room[i].time9) { cr_time9 = 1; } else { cr_time9 = 0; }
            if (data.room[i].time10) { cr_time10 = 1; } else { cr_time10 = 0; }
            if (data.room[i].time11) { cr_time11 = 1; } else { cr_time11 = 0; }
            if (data.room[i].time12) { cr_time12 = 1; } else { cr_time12 = 0; }
            if (data.room[i].time13) { cr_time13 = 1; } else { cr_time13 = 0; }

            var day_id = parseInt([i]) + 1;

            var ns_time1 = parseInt(cs_time1);
            var ns_time2 = parseInt(cs_time2);
            var ns_time3 = parseInt(cs_time3);
            var ns_time4 = parseInt(cs_time4);
            var ns_time5 = parseInt(cs_time5);
            var ns_time6 = parseInt(cs_time6);
            var ns_time7 = parseInt(cs_time7);
            var ns_time8 = parseInt(cs_time8);
            var ns_time9 = parseInt(cs_time9);
            var ns_time10 = parseInt(cs_time10);
            var ns_time11 = parseInt(cs_time11);
            var ns_time12 = parseInt(cs_time12);
            var ns_time13 = parseInt(cs_time13);

            var nt_time1 = parseInt(ct_time1);
            var nt_time2 = parseInt(ct_time2);
            var nt_time3 = parseInt(ct_time3);
            var nt_time4 = parseInt(ct_time4);
            var nt_time5 = parseInt(ct_time5);
            var nt_time6 = parseInt(ct_time6);
            var nt_time7 = parseInt(ct_time7);
            var nt_time8 = parseInt(ct_time8);
            var nt_time9 = parseInt(ct_time9);
            var nt_time10 = parseInt(ct_time10);
            var nt_time11 = parseInt(ct_time11);
            var nt_time12 = parseInt(ct_time12);
            var nt_time13 = parseInt(ct_time13);

            var nr_time1 = parseInt(cr_time1);
            var nr_time2 = parseInt(cr_time2);
            var nr_time3 = parseInt(cr_time3);
            var nr_time4 = parseInt(cr_time4);
            var nr_time5 = parseInt(cr_time5);
            var nr_time6 = parseInt(cr_time6);
            var nr_time7 = parseInt(cr_time7);
            var nr_time8 = parseInt(cr_time8);
            var nr_time9 = parseInt(cr_time9);
            var nr_time10 = parseInt(cr_time10);
            var nr_time11 = parseInt(cr_time11);
            var nr_time12 = parseInt(cr_time12);
            var nr_time13 = parseInt(cr_time13);

            var d_time1 = ns_time1 || nt_time1 || nr_time1;
            var d_time2 = ns_time2 || nt_time2 || nr_time2;
            var d_time3 = ns_time3 || nt_time3 || nr_time3;
            var d_time4 = ns_time4 || nt_time4 || nr_time4;
            var d_time5 = ns_time5 || nt_time5 || nr_time5;
            var d_time6 = ns_time6 || nt_time6 || nr_time6;
            var d_time7 = ns_time7 || nt_time7 || nr_time7;
            var d_time8 = ns_time8 || nt_time8 || nr_time8;
            var d_time9 = ns_time9 || nt_time9 || nr_time9;
            var d_time10 = ns_time10 || nt_time10 || nr_time10;
            var d_time11 = ns_time11 || nt_time11 || nr_time11;
            var d_time12 = ns_time12 || nt_time12 || nr_time12;
            var d_time13 = ns_time13 || nt_time13 || nr_time13;

            if (d_time1 == 0) { d_time1 = ""; } else { if (ns_time1 == 1) { d_time1 = data.student[i].time1 } else { d_time1 = "Busy" }; }
            if (d_time2 == 0) { d_time2 = ""; } else { if (ns_time2 == 1) { d_time2 = data.student[i].time2 } else { d_time2 = "Busy" }; }
            if (d_time3 == 0) { d_time3 = ""; } else { if (ns_time3 == 1) { d_time3 = data.student[i].time3 } else { d_time3 = "Busy" }; }
            if (d_time4 == 0) { d_time4 = ""; } else { if (ns_time4 == 1) { d_time4 = data.student[i].time4 } else { d_time4 = "Busy" }; }
            if (d_time5 == 0) { d_time5 = ""; } else { if (ns_time5 == 1) { d_time5 = data.student[i].time5 } else { d_time5 = "Busy" }; }
            if (d_time6 == 0) { d_time6 = ""; } else { if (ns_time6 == 1) { d_time6 = data.student[i].time6 } else { d_time6 = "Busy" }; }
            if (d_time7 == 0) { d_time7 = ""; } else { if (ns_time7 == 1) { d_time7 = data.student[i].time7 } else { d_time7 = "Busy" }; }
            if (d_time8 == 0) { d_time8 = ""; } else { if (ns_time8 == 1) { d_time8 = data.student[i].time8 } else { d_time8 = "Busy" }; }
            if (d_time9 == 0) { d_time9 = ""; } else { if (ns_time9 == 1) { d_time9 = data.student[i].time9 } else { d_time9 = "Busy" }; }
            if (d_time10 == 0) { d_time10 = ""; } else { if (ns_time10 == 1) { d_time10 = data.student[i].time10 } else { d_time10 = "Busy" }; }
            if (d_time11 == 0) { d_time11 = ""; } else { if (ns_time11 == 1) { d_time11 = data.student[i].time11 } else { d_time11 = "Busy" }; }
            if (d_time12 == 0) { d_time12 = ""; } else { if (ns_time12 == 1) { d_time12 = data.student[i].time12 } else { d_time12 = "Busy" }; }
            if (d_time13 == 0) { d_time13 = ""; } else { if (ns_time13 == 1) { d_time13 = data.student[i].time13 } else { d_time13 = "Busy" }; }

            var SQL = `UPDATE display_timetable SET time1 = '${d_time1}', time2 = '${d_time2}', time3 = '${d_time3}', time4 = '${d_time4}', time5 = '${d_time5}', time6 = '${d_time6}', time7 = '${d_time7}', time8 = '${d_time8}', time9 = '${d_time9}', time10 = '${d_time10}', time11 = '${d_time11}', time12 = '${d_time12}', time13 = '${d_time13}'
            WHERE day_id = '${day_id}'`;
            await db.query(SQL, [d_time1, d_time2, d_time3, d_time4, d_time5, d_time6, d_time7, d_time8, d_time9, d_time10, d_time11, d_time12, d_time13, day_id]);
        }
        var selectSQL = `SELECT day.day_name,
        display_timetable.time1, display_timetable.time2, display_timetable.time3, display_timetable.time4,
        display_timetable.time5, display_timetable.time6, display_timetable.time7, display_timetable.time8,
        display_timetable.time9, display_timetable.time10, display_timetable.time11, display_timetable.time12,
        display_timetable.time13
        FROM day
        LEFT JOIN display_timetable ON display_timetable.day_id = day.day_id
        ORDER BY display_timetable.day_id`;
        await db.query(selectSQL, callback);
    },

    //select timetable student_groups , teacher , room , rooml
    selectTimetableRR: async function (data, callback) {
        var cs_time1; var cs_time2; var cs_time3;
        var cs_time4; var cs_time5; var cs_time6;
        var cs_time7; var cs_time8; var cs_time9;
        var cs_time10; var cs_time11; var cs_time12;
        var cs_time13;

        var ct_time1; var ct_time2; var ct_time3;
        var ct_time4; var ct_time5; var ct_time6;
        var ct_time7; var ct_time8; var ct_time9;
        var ct_time10; var ct_time11; var ct_time12;
        var ct_time13;

        var cr_time1; var cr_time2; var cr_time3;
        var cr_time4; var cr_time5; var cr_time6;
        var cr_time7; var cr_time8; var cr_time9;
        var cr_time10; var cr_time11; var cr_time12;
        var cr_time13;

        var crl_time1; var crl_time2; var crl_time3;
        var crl_time4; var crl_time5; var crl_time6;
        var crl_time7; var crl_time8; var crl_time9;
        var crl_time10; var crl_time11; var crl_time12;
        var crl_time13;


        for (let i = 0; i <= 6; i++) {

            if (data.student[i].time1) { cs_time1 = 1; } else { cs_time1 = 0; }
            if (data.student[i].time2) { cs_time2 = 1; } else { cs_time2 = 0; }
            if (data.student[i].time3) { cs_time3 = 1; } else { cs_time3 = 0; }
            if (data.student[i].time4) { cs_time4 = 1; } else { cs_time4 = 0; }
            if (data.student[i].time5) { cs_time5 = 1; } else { cs_time5 = 0; }
            if (data.student[i].time6) { cs_time6 = 1; } else { cs_time6 = 0; }
            if (data.student[i].time7) { cs_time7 = 1; } else { cs_time7 = 0; }
            if (data.student[i].time8) { cs_time8 = 1; } else { cs_time8 = 0; }
            if (data.student[i].time9) { cs_time9 = 1; } else { cs_time9 = 0; }
            if (data.student[i].time10) { cs_time10 = 1; } else { cs_time10 = 0; }
            if (data.student[i].time11) { cs_time11 = 1; } else { cs_time11 = 0; }
            if (data.student[i].time12) { cs_time12 = 1; } else { cs_time12 = 0; }
            if (data.student[i].time13) { cs_time13 = 1; } else { cs_time13 = 0; }

            if (data.teacher[i].time1) { ct_time1 = 1; } else { ct_time1 = 0; }
            if (data.teacher[i].time2) { ct_time2 = 1; } else { ct_time2 = 0; }
            if (data.teacher[i].time3) { ct_time3 = 1; } else { ct_time3 = 0; }
            if (data.teacher[i].time4) { ct_time4 = 1; } else { ct_time4 = 0; }
            if (data.teacher[i].time5) { ct_time5 = 1; } else { ct_time5 = 0; }
            if (data.teacher[i].time6) { ct_time6 = 1; } else { ct_time6 = 0; }
            if (data.teacher[i].time7) { ct_time7 = 1; } else { ct_time7 = 0; }
            if (data.teacher[i].time8) { ct_time8 = 1; } else { ct_time8 = 0; }
            if (data.teacher[i].time9) { ct_time9 = 1; } else { ct_time9 = 0; }
            if (data.teacher[i].time10) { ct_time10 = 1; } else { ct_time10 = 0; }
            if (data.teacher[i].time11) { ct_time11 = 1; } else { ct_time11 = 0; }
            if (data.teacher[i].time12) { ct_time12 = 1; } else { ct_time12 = 0; }
            if (data.teacher[i].time13) { ct_time13 = 1; } else { ct_time13 = 0; }

            if (data.room[i].time1) { cr_time1 = 1; } else { cr_time1 = 0; }
            if (data.room[i].time2) { cr_time2 = 1; } else { cr_time2 = 0; }
            if (data.room[i].time3) { cr_time3 = 1; } else { cr_time3 = 0; }
            if (data.room[i].time4) { cr_time4 = 1; } else { cr_time4 = 0; }
            if (data.room[i].time5) { cr_time5 = 1; } else { cr_time5 = 0; }
            if (data.room[i].time6) { cr_time6 = 1; } else { cr_time6 = 0; }
            if (data.room[i].time7) { cr_time7 = 1; } else { cr_time7 = 0; }
            if (data.room[i].time8) { cr_time8 = 1; } else { cr_time8 = 0; }
            if (data.room[i].time9) { cr_time9 = 1; } else { cr_time9 = 0; }
            if (data.room[i].time10) { cr_time10 = 1; } else { cr_time10 = 0; }
            if (data.room[i].time11) { cr_time11 = 1; } else { cr_time11 = 0; }
            if (data.room[i].time12) { cr_time12 = 1; } else { cr_time12 = 0; }
            if (data.room[i].time13) { cr_time13 = 1; } else { cr_time13 = 0; }

            if (data.rooml[i].time1) { crl_time1 = 1; } else { crl_time1 = 0; }
            if (data.rooml[i].time2) { crl_time2 = 1; } else { crl_time2 = 0; }
            if (data.rooml[i].time3) { crl_time3 = 1; } else { crl_time3 = 0; }
            if (data.rooml[i].time4) { crl_time4 = 1; } else { crl_time4 = 0; }
            if (data.rooml[i].time5) { crl_time5 = 1; } else { crl_time5 = 0; }
            if (data.rooml[i].time6) { crl_time6 = 1; } else { crl_time6 = 0; }
            if (data.rooml[i].time7) { crl_time7 = 1; } else { crl_time7 = 0; }
            if (data.rooml[i].time8) { crl_time8 = 1; } else { crl_time8 = 0; }
            if (data.rooml[i].time9) { crl_time9 = 1; } else { crl_time9 = 0; }
            if (data.rooml[i].time10) { crl_time10 = 1; } else { crl_time10 = 0; }
            if (data.rooml[i].time11) { crl_time11 = 1; } else { crl_time11 = 0; }
            if (data.rooml[i].time12) { crl_time12 = 1; } else { crl_time12 = 0; }
            if (data.rooml[i].time13) { crl_time13 = 1; } else { crl_time13 = 0; }

            var day_id = parseInt([i]) + 1;

            var ns_time1 = parseInt(cs_time1);
            var ns_time2 = parseInt(cs_time2);
            var ns_time3 = parseInt(cs_time3);
            var ns_time4 = parseInt(cs_time4);
            var ns_time5 = parseInt(cs_time5);
            var ns_time6 = parseInt(cs_time6);
            var ns_time7 = parseInt(cs_time7);
            var ns_time8 = parseInt(cs_time8);
            var ns_time9 = parseInt(cs_time9);
            var ns_time10 = parseInt(cs_time10);
            var ns_time11 = parseInt(cs_time11);
            var ns_time12 = parseInt(cs_time12);
            var ns_time13 = parseInt(cs_time13);

            var nt_time1 = parseInt(ct_time1);
            var nt_time2 = parseInt(ct_time2);
            var nt_time3 = parseInt(ct_time3);
            var nt_time4 = parseInt(ct_time4);
            var nt_time5 = parseInt(ct_time5);
            var nt_time6 = parseInt(ct_time6);
            var nt_time7 = parseInt(ct_time7);
            var nt_time8 = parseInt(ct_time8);
            var nt_time9 = parseInt(ct_time9);
            var nt_time10 = parseInt(ct_time10);
            var nt_time11 = parseInt(ct_time11);
            var nt_time12 = parseInt(ct_time12);
            var nt_time13 = parseInt(ct_time13);

            var nr_time1 = parseInt(cr_time1);
            var nr_time2 = parseInt(cr_time2);
            var nr_time3 = parseInt(cr_time3);
            var nr_time4 = parseInt(cr_time4);
            var nr_time5 = parseInt(cr_time5);
            var nr_time6 = parseInt(cr_time6);
            var nr_time7 = parseInt(cr_time7);
            var nr_time8 = parseInt(cr_time8);
            var nr_time9 = parseInt(cr_time9);
            var nr_time10 = parseInt(cr_time10);
            var nr_time11 = parseInt(cr_time11);
            var nr_time12 = parseInt(cr_time12);
            var nr_time13 = parseInt(cr_time13);

            var nrl_time1 = parseInt(crl_time1);
            var nrl_time2 = parseInt(crl_time2);
            var nrl_time3 = parseInt(crl_time3);
            var nrl_time4 = parseInt(crl_time4);
            var nrl_time5 = parseInt(crl_time5);
            var nrl_time6 = parseInt(crl_time6);
            var nrl_time7 = parseInt(crl_time7);
            var nrl_time8 = parseInt(crl_time8);
            var nrl_time9 = parseInt(crl_time9);
            var nrl_time10 = parseInt(crl_time10);
            var nrl_time11 = parseInt(crl_time11);
            var nrl_time12 = parseInt(crl_time12);
            var nrl_time13 = parseInt(crl_time13);

            var d_time1 = ns_time1 || nt_time1 || nr_time1 || nrl_time1;
            var d_time2 = ns_time2 || nt_time2 || nr_time2 || nrl_time2;
            var d_time3 = ns_time3 || nt_time3 || nr_time3 || nrl_time3;
            var d_time4 = ns_time4 || nt_time4 || nr_time4 || nrl_time4;
            var d_time5 = ns_time5 || nt_time5 || nr_time5 || nrl_time5;
            var d_time6 = ns_time6 || nt_time6 || nr_time6 || nrl_time6;
            var d_time7 = ns_time7 || nt_time7 || nr_time7 || nrl_time7;
            var d_time8 = ns_time8 || nt_time8 || nr_time8 || nrl_time8;
            var d_time9 = ns_time9 || nt_time9 || nr_time9 || nrl_time9;
            var d_time10 = ns_time10 || nt_time10 || nr_time10 || nrl_time10;
            var d_time11 = ns_time11 || nt_time11 || nr_time11 || nrl_time11;
            var d_time12 = ns_time12 || nt_time12 || nr_time12 || nrl_time12;
            var d_time13 = ns_time13 || nt_time13 || nr_time13 || nrl_time13;

            if (d_time1 == 0) { d_time1 = ""; } else { if (ns_time1 == 1) { d_time1 = data.student[i].time1 } else { d_time1 = "Busy" }; }
            if (d_time2 == 0) { d_time2 = ""; } else { if (ns_time2 == 1) { d_time2 = data.student[i].time2 } else { d_time2 = "Busy" }; }
            if (d_time3 == 0) { d_time3 = ""; } else { if (ns_time3 == 1) { d_time3 = data.student[i].time3 } else { d_time3 = "Busy" }; }
            if (d_time4 == 0) { d_time4 = ""; } else { if (ns_time4 == 1) { d_time4 = data.student[i].time4 } else { d_time4 = "Busy" }; }
            if (d_time5 == 0) { d_time5 = ""; } else { if (ns_time5 == 1) { d_time5 = data.student[i].time5 } else { d_time5 = "Busy" }; }
            if (d_time6 == 0) { d_time6 = ""; } else { if (ns_time6 == 1) { d_time6 = data.student[i].time6 } else { d_time6 = "Busy" }; }
            if (d_time7 == 0) { d_time7 = ""; } else { if (ns_time7 == 1) { d_time7 = data.student[i].time7 } else { d_time7 = "Busy" }; }
            if (d_time8 == 0) { d_time8 = ""; } else { if (ns_time8 == 1) { d_time8 = data.student[i].time8 } else { d_time8 = "Busy" }; }
            if (d_time9 == 0) { d_time9 = ""; } else { if (ns_time9 == 1) { d_time9 = data.student[i].time9 } else { d_time9 = "Busy" }; }
            if (d_time10 == 0) { d_time10 = ""; } else { if (ns_time10 == 1) { d_time10 = data.student[i].time10 } else { d_time10 = "Busy" }; }
            if (d_time11 == 0) { d_time11 = ""; } else { if (ns_time11 == 1) { d_time11 = data.student[i].time11 } else { d_time11 = "Busy" }; }
            if (d_time12 == 0) { d_time12 = ""; } else { if (ns_time12 == 1) { d_time12 = data.student[i].time12 } else { d_time12 = "Busy" }; }
            if (d_time13 == 0) { d_time13 = ""; } else { if (ns_time13 == 1) { d_time13 = data.student[i].time13 } else { d_time13 = "Busy" }; }

            var SQL = `UPDATE display_timetable SET time1 = '${d_time1}', time2 = '${d_time2}', time3 = '${d_time3}', time4 = '${d_time4}', time5 = '${d_time5}', time6 = '${d_time6}', time7 = '${d_time7}', time8 = '${d_time8}', time9 = '${d_time9}', time10 = '${d_time10}', time11 = '${d_time11}', time12 = '${d_time12}', time13 = '${d_time13}'
            WHERE day_id = '${day_id}'`;
            await db.query(SQL, [d_time1, d_time2, d_time3, d_time4, d_time5, d_time6, d_time7, d_time8, d_time9, d_time10, d_time11, d_time12, d_time13, day_id]);
        }
        var selectSQL = `SELECT day.day_name,
        display_timetable.time1, display_timetable.time2, display_timetable.time3, display_timetable.time4,
        display_timetable.time5, display_timetable.time6, display_timetable.time7, display_timetable.time8,
        display_timetable.time9, display_timetable.time10, display_timetable.time11, display_timetable.time12,
        display_timetable.time13
        FROM day
        LEFT JOIN display_timetable ON display_timetable.day_id = day.day_id
        ORDER BY display_timetable.day_id`;
        await db.query(selectSQL, callback);
    },

    //select timetable student_groups , teacher , room , room l , test
    selectTimetableRRT: async function (data, callback) {
        var day_id = data.day_id;
        var time1; var time2; var time3;
        var time4; var time5; var time6;
        var time7; var time8; var time9;
        var time10; var time11; var time12;
        var time13;
        var subject_name = data.subject_name;
        var subject_unit = data.subject_unit;

        var cs_time1; var cs_time2; var cs_time3;
        var cs_time4; var cs_time5; var cs_time6;
        var cs_time7; var cs_time8; var cs_time9;
        var cs_time10; var cs_time11; var cs_time12;
        var cs_time13;

        var ct_time1; var ct_time2; var ct_time3;
        var ct_time4; var ct_time5; var ct_time6;
        var ct_time7; var ct_time8; var ct_time9;
        var ct_time10; var ct_time11; var ct_time12;
        var ct_time13;

        var cr_time1; var cr_time2; var cr_time3;
        var cr_time4; var cr_time5; var cr_time6;
        var cr_time7; var cr_time8; var cr_time9;
        var cr_time10; var cr_time11; var cr_time12;
        var cr_time13;

        var crl_time1; var crl_time2; var crl_time3;
        var crl_time4; var crl_time5; var crl_time6;
        var crl_time7; var crl_time8; var crl_time9;
        var crl_time10; var crl_time11; var crl_time12;
        var crl_time13;


        for (let i = 0; i <= 6; i++) {
            if (data.student[i].time1) { cs_time1 = 1; } else { cs_time1 = 0; }
            if (data.student[i].time2) { cs_time2 = 1; } else { cs_time2 = 0; }
            if (data.student[i].time3) { cs_time3 = 1; } else { cs_time3 = 0; }
            if (data.student[i].time4) { cs_time4 = 1; } else { cs_time4 = 0; }
            if (data.student[i].time5) { cs_time5 = 1; } else { cs_time5 = 0; }
            if (data.student[i].time6) { cs_time6 = 1; } else { cs_time6 = 0; }
            if (data.student[i].time7) { cs_time7 = 1; } else { cs_time7 = 0; }
            if (data.student[i].time8) { cs_time8 = 1; } else { cs_time8 = 0; }
            if (data.student[i].time9) { cs_time9 = 1; } else { cs_time9 = 0; }
            if (data.student[i].time10) { cs_time10 = 1; } else { cs_time10 = 0; }
            if (data.student[i].time11) { cs_time11 = 1; } else { cs_time11 = 0; }
            if (data.student[i].time12) { cs_time12 = 1; } else { cs_time12 = 0; }
            if (data.student[i].time13) { cs_time13 = 1; } else { cs_time13 = 0; }

            if (data.teacher[i].time1) { ct_time1 = 1; } else { ct_time1 = 0; }
            if (data.teacher[i].time2) { ct_time2 = 1; } else { ct_time2 = 0; }
            if (data.teacher[i].time3) { ct_time3 = 1; } else { ct_time3 = 0; }
            if (data.teacher[i].time4) { ct_time4 = 1; } else { ct_time4 = 0; }
            if (data.teacher[i].time5) { ct_time5 = 1; } else { ct_time5 = 0; }
            if (data.teacher[i].time6) { ct_time6 = 1; } else { ct_time6 = 0; }
            if (data.teacher[i].time7) { ct_time7 = 1; } else { ct_time7 = 0; }
            if (data.teacher[i].time8) { ct_time8 = 1; } else { ct_time8 = 0; }
            if (data.teacher[i].time9) { ct_time9 = 1; } else { ct_time9 = 0; }
            if (data.teacher[i].time10) { ct_time10 = 1; } else { ct_time10 = 0; }
            if (data.teacher[i].time11) { ct_time11 = 1; } else { ct_time11 = 0; }
            if (data.teacher[i].time12) { ct_time12 = 1; } else { ct_time12 = 0; }
            if (data.teacher[i].time13) { ct_time13 = 1; } else { ct_time13 = 0; }

            if (data.room[i].time1) { cr_time1 = 1; } else { cr_time1 = 0; }
            if (data.room[i].time2) { cr_time2 = 1; } else { cr_time2 = 0; }
            if (data.room[i].time3) { cr_time3 = 1; } else { cr_time3 = 0; }
            if (data.room[i].time4) { cr_time4 = 1; } else { cr_time4 = 0; }
            if (data.room[i].time5) { cr_time5 = 1; } else { cr_time5 = 0; }
            if (data.room[i].time6) { cr_time6 = 1; } else { cr_time6 = 0; }
            if (data.room[i].time7) { cr_time7 = 1; } else { cr_time7 = 0; }
            if (data.room[i].time8) { cr_time8 = 1; } else { cr_time8 = 0; }
            if (data.room[i].time9) { cr_time9 = 1; } else { cr_time9 = 0; }
            if (data.room[i].time10) { cr_time10 = 1; } else { cr_time10 = 0; }
            if (data.room[i].time11) { cr_time11 = 1; } else { cr_time11 = 0; }
            if (data.room[i].time12) { cr_time12 = 1; } else { cr_time12 = 0; }
            if (data.room[i].time13) { cr_time13 = 1; } else { cr_time13 = 0; }

            if (data.rooml[i].time1) { crl_time1 = 1; } else { crl_time1 = 0; }
            if (data.rooml[i].time2) { crl_time2 = 1; } else { crl_time2 = 0; }
            if (data.rooml[i].time3) { crl_time3 = 1; } else { crl_time3 = 0; }
            if (data.rooml[i].time4) { crl_time4 = 1; } else { crl_time4 = 0; }
            if (data.rooml[i].time5) { crl_time5 = 1; } else { crl_time5 = 0; }
            if (data.rooml[i].time6) { crl_time6 = 1; } else { crl_time6 = 0; }
            if (data.rooml[i].time7) { crl_time7 = 1; } else { crl_time7 = 0; }
            if (data.rooml[i].time8) { crl_time8 = 1; } else { crl_time8 = 0; }
            if (data.rooml[i].time9) { crl_time9 = 1; } else { crl_time9 = 0; }
            if (data.rooml[i].time10) { crl_time10 = 1; } else { crl_time10 = 0; }
            if (data.rooml[i].time11) { crl_time11 = 1; } else { crl_time11 = 0; }
            if (data.rooml[i].time12) { crl_time12 = 1; } else { crl_time12 = 0; }
            if (data.rooml[i].time13) { crl_time13 = 1; } else { crl_time13 = 0; }

            var day = parseInt([i]) + 1;

            var ns_time1 = parseInt(cs_time1);
            var ns_time2 = parseInt(cs_time2);
            var ns_time3 = parseInt(cs_time3);
            var ns_time4 = parseInt(cs_time4);
            var ns_time5 = parseInt(cs_time5);
            var ns_time6 = parseInt(cs_time6);
            var ns_time7 = parseInt(cs_time7);
            var ns_time8 = parseInt(cs_time8);
            var ns_time9 = parseInt(cs_time9);
            var ns_time10 = parseInt(cs_time10);
            var ns_time11 = parseInt(cs_time11);
            var ns_time12 = parseInt(cs_time12);
            var ns_time13 = parseInt(cs_time13);

            var nt_time1 = parseInt(ct_time1);
            var nt_time2 = parseInt(ct_time2);
            var nt_time3 = parseInt(ct_time3);
            var nt_time4 = parseInt(ct_time4);
            var nt_time5 = parseInt(ct_time5);
            var nt_time6 = parseInt(ct_time6);
            var nt_time7 = parseInt(ct_time7);
            var nt_time8 = parseInt(ct_time8);
            var nt_time9 = parseInt(ct_time9);
            var nt_time10 = parseInt(ct_time10);
            var nt_time11 = parseInt(ct_time11);
            var nt_time12 = parseInt(ct_time12);
            var nt_time13 = parseInt(ct_time13);

            var nr_time1 = parseInt(cr_time1);
            var nr_time2 = parseInt(cr_time2);
            var nr_time3 = parseInt(cr_time3);
            var nr_time4 = parseInt(cr_time4);
            var nr_time5 = parseInt(cr_time5);
            var nr_time6 = parseInt(cr_time6);
            var nr_time7 = parseInt(cr_time7);
            var nr_time8 = parseInt(cr_time8);
            var nr_time9 = parseInt(cr_time9);
            var nr_time10 = parseInt(cr_time10);
            var nr_time11 = parseInt(cr_time11);
            var nr_time12 = parseInt(cr_time12);
            var nr_time13 = parseInt(cr_time13);

            var nrl_time1 = parseInt(crl_time1);
            var nrl_time2 = parseInt(crl_time2);
            var nrl_time3 = parseInt(crl_time3);
            var nrl_time4 = parseInt(crl_time4);
            var nrl_time5 = parseInt(crl_time5);
            var nrl_time6 = parseInt(crl_time6);
            var nrl_time7 = parseInt(crl_time7);
            var nrl_time8 = parseInt(crl_time8);
            var nrl_time9 = parseInt(crl_time9);
            var nrl_time10 = parseInt(crl_time10);
            var nrl_time11 = parseInt(crl_time11);
            var nrl_time12 = parseInt(crl_time12);
            var nrl_time13 = parseInt(crl_time13);

            var d_time1 = ns_time1 || nt_time1 || nr_time1 || nrl_time1;
            var d_time2 = ns_time2 || nt_time2 || nr_time2 || nrl_time2;
            var d_time3 = ns_time3 || nt_time3 || nr_time3 || nrl_time3;
            var d_time4 = ns_time4 || nt_time4 || nr_time4 || nrl_time4;
            var d_time5 = ns_time5 || nt_time5 || nr_time5 || nrl_time5;
            var d_time6 = ns_time6 || nt_time6 || nr_time6 || nrl_time6;
            var d_time7 = ns_time7 || nt_time7 || nr_time7 || nrl_time7;
            var d_time8 = ns_time8 || nt_time8 || nr_time8 || nrl_time8;
            var d_time9 = ns_time9 || nt_time9 || nr_time9 || nrl_time9;
            var d_time10 = ns_time10 || nt_time10 || nr_time10 || nrl_time10;
            var d_time11 = ns_time11 || nt_time11 || nr_time11 || nrl_time11;
            var d_time12 = ns_time12 || nt_time12 || nr_time12 || nrl_time12;
            var d_time13 = ns_time13 || nt_time13 || nr_time13 || nrl_time13;


            if (d_time1 == 0) { d_time1 = ""; } else { if (ns_time1 == 1) { d_time1 = data.student[i].time1 } else { d_time1 = "Busy" }; }
            if (d_time2 == 0) { d_time2 = ""; } else { if (ns_time2 == 1) { d_time2 = data.student[i].time2 } else { d_time2 = "Busy" }; }
            if (d_time3 == 0) { d_time3 = ""; } else { if (ns_time3 == 1) { d_time3 = data.student[i].time3 } else { d_time3 = "Busy" }; }
            if (d_time4 == 0) { d_time4 = ""; } else { if (ns_time4 == 1) { d_time4 = data.student[i].time4 } else { d_time4 = "Busy" }; }
            if (d_time5 == 0) { d_time5 = ""; } else { if (ns_time5 == 1) { d_time5 = data.student[i].time5 } else { d_time5 = "Busy" }; }
            if (d_time6 == 0) { d_time6 = ""; } else { if (ns_time6 == 1) { d_time6 = data.student[i].time6 } else { d_time6 = "Busy" }; }
            if (d_time7 == 0) { d_time7 = ""; } else { if (ns_time7 == 1) { d_time7 = data.student[i].time7 } else { d_time7 = "Busy" }; }
            if (d_time8 == 0) { d_time8 = ""; } else { if (ns_time8 == 1) { d_time8 = data.student[i].time8 } else { d_time8 = "Busy" }; }
            if (d_time9 == 0) { d_time9 = ""; } else { if (ns_time9 == 1) { d_time9 = data.student[i].time9 } else { d_time9 = "Busy" }; }
            if (d_time10 == 0) { d_time10 = ""; } else { if (ns_time10 == 1) { d_time10 = data.student[i].time10 } else { d_time10 = "Busy" }; }
            if (d_time11 == 0) { d_time11 = ""; } else { if (ns_time11 == 1) { d_time11 = data.student[i].time11 } else { d_time11 = "Busy" }; }
            if (d_time12 == 0) { d_time12 = ""; } else { if (ns_time12 == 1) { d_time12 = data.student[i].time12 } else { d_time12 = "Busy" }; }
            if (d_time13 == 0) { d_time13 = ""; } else { if (ns_time13 == 1) { d_time13 = data.student[i].time13 } else { d_time13 = "Busy" }; }

            var SQL = `UPDATE display_timetable SET time1 = '${d_time1}', time2 = '${d_time2}', time3 = '${d_time3}', time4 = '${d_time4}', time5 = '${d_time5}', time6 = '${d_time6}', time7 = '${d_time7}', time8 = '${d_time8}', time9 = '${d_time9}', time10 = '${d_time10}', time11 = '${d_time11}', time12 = '${d_time12}', time13 = '${d_time13}'
            WHERE day_id = '${day}'`;
            await db.query(SQL, [d_time1, d_time2, d_time3, d_time4, d_time5, d_time6, d_time7, d_time8, d_time9, d_time10, d_time11, d_time12, d_time13, day]);
        }
        var input = subject_unit;
        var output1 = input.substring(2, 3);
        var output2 = input.substring(4, 5);
        var a = parseInt(output1)
        var b = parseInt(output2)
        console.log(output1, output2)
        var output3 = a + b - 1;
        console.log(output3)
        var time = data.time;
        var time = parseInt(data.time)
        var column = time;
        if (input === subject_unit) {
            time += output3;
            console.log("time", time, "column", column)
            for (var i = column; i <= time; i++) {
                console.log("i", i)
                switch (i) {
                    case 1: time1 = subject_name; break;
                    case 2: time2 = subject_name; break;
                    case 3: time3 = subject_name; break;
                    case 4: time4 = subject_name; break;
                    case 5: time5 = subject_name; break;
                    case 6: time6 = subject_name; break;
                    case 7: time7 = subject_name; break;
                    case 8: time8 = subject_name; break;
                    case 9: time9 = subject_name; break;
                    case 10: time10 = subject_name; break;
                    case 11: time11 = subject_name; break;
                    case 12: time12 = subject_name; break;
                    case 13: time13 = subject_name; break;
                }
                var arr = parseInt(day_id) - 1;
                if (time1 == null) {
                    time1 = "";
                    if (data.room[arr].time1) {
                        time1 = "Busy";
                    }
                    if (data.rooml[arr].time1) {
                        time1 = "Busy";
                    }
                    if (data.teacher[arr].time1) {
                        time1 = "Busy";
                    }
                }
                else {
                    if (data.student[arr].time1) {
                        time1 = data.student[arr].time1;
                    }
                    if (data.room[arr].time1) {
                        time1 = "Busy";
                    }
                    if (data.rooml[arr].time1) {
                        time1 = "Busy";
                    }
                    if (data.teacher[arr].time1) {
                        time1 = "Busy";
                    }
                    if (data.student[arr].time1) {
                        time1 = "Busy";
                    }
                }
                if (time2 == null) {
                    time2 = "";
                    if (data.room[arr].time2) {
                        time2 = "Busy";
                    }
                    if (data.rooml[arr].time2) {
                        time2 = "Busy";
                    }
                    if (data.teacher[arr].time2) {
                        time2 = "Busy";
                    }
                }
                else {
                    if (data.student[arr].time2) {
                        time2 = data.student[arr].time2;
                    }
                    if (data.room[arr].time2) {
                        time2 = "Busy";
                    }
                    if (data.rooml[arr].time2) {
                        time2 = "Busy";
                    }
                    if (data.teacher[arr].time2) {
                        time2 = "Busy";
                    }
                    if (data.student[arr].time2) {
                        time2 = "Busy";
                    }
                }
                if (time3 == null) {
                    time3 = "";
                    if (data.room[arr].time3) {
                        time3 = "Busy";
                    }
                    if (data.rooml[arr].time3) {
                        time3 = "Busy";
                    }
                    if (data.teacher[arr].time3) {
                        time3 = "Busy";
                    }
                }
                else {
                    if (data.student[arr].time3) {
                        time3 = data.student[arr].time3;
                    }
                    if (data.room[arr].time3) {
                        time3 = "Busy";
                    }
                    if (data.rooml[arr].time3) {
                        time3 = "Busy";
                    }
                    if (data.teacher[arr].time3) {
                        time3 = "Busy";
                    }
                    if (data.student[arr].time3) {
                        time3 = "Busy";
                    }
                }
                if (time4 == null) {
                    time4 = "";
                    if (data.room[arr].time4) {
                        time4 = "Busy";
                    }
                    if (data.rooml[arr].time4) {
                        time4 = "Busy";
                    }
                    if (data.teacher[arr].time4) {
                        time4 = "Busy";
                    }
                }
                else {
                    if (data.student[arr].time4) {
                        time4 = data.student[arr].time4;
                    }
                    if (data.room[arr].time4) {
                        time4 = "Busy";
                    }
                    if (data.rooml[arr].time4) {
                        time4 = "Busy";
                    }
                    if (data.teacher[arr].time4) {
                        time4 = "Busy";
                    }
                    if (data.student[arr].time4) {
                        time4 = "Busy";
                    }
                }
                if (time5 == null) {
                    time5 = "";
                    if (data.room[arr].time5) {
                        time5 = "Busy";
                    }
                    if (data.rooml[arr].time5) {
                        time5 = "Busy";
                    }
                    if (data.teacher[arr].time5) {
                        time5 = "Busy";
                    }
                }
                else {
                    if (data.student[arr].time5) {
                        time5 = data.student[arr].time5;
                    }
                    if (data.room[arr].time5) {
                        time5 = "Busy";
                    }
                    if (data.rooml[arr].time5) {
                        time5 = "Busy";
                    }
                    if (data.teacher[arr].time5) {
                        time5 = "Busy";
                    }
                    if (data.student[arr].time5) {
                        time5 = "Busy";
                    }
                }
                if (time6 == null) {
                    time6 = "";
                    if (data.room[arr].time6) {
                        time6 = "Busy";
                    }
                    if (data.rooml[arr].time6) {
                        time6 = "Busy";
                    }
                    if (data.teacher[arr].time6) {
                        time6 = "Busy";
                    }
                }
                else {
                    if (data.student[arr].time6) {
                        time6 = data.student[arr].time6;
                    }
                    if (data.room[arr].time6) {
                        time6 = "Busy";
                    }
                    if (data.rooml[arr].time6) {
                        time6 = "Busy";
                    }
                    if (data.teacher[arr].time6) {
                        time6 = "Busy";
                    }
                    if (data.student[arr].time6) {
                        time6 = "Busy";
                    }
                }
                if (time7 == null) {
                    time7 = "";
                    if (data.room[arr].time7) {
                        time7 = "Busy";
                    }
                    if (data.rooml[arr].time7) {
                        time7 = "Busy";
                    }
                    if (data.teacher[arr].time7) {
                        time7 = "Busy";
                    }
                }
                else {
                    if (data.student[arr].time7) {
                        time7 = data.student[arr].time7;
                    }
                    if (data.room[arr].time7) {
                        time7 = "Busy";
                    }
                    if (data.rooml[arr].time7) {
                        time7 = "Busy";
                    }
                    if (data.teacher[arr].time7) {
                        time7 = "Busy";
                    }
                    if (data.student[arr].time7) {
                        time7 = "Busy";
                    }
                }
                if (time8 == null) {
                    time8 = "";
                    if (data.room[arr].time8) {
                        time8 = "Busy";
                    }
                    if (data.rooml[arr].time8) {
                        time8 = "Busy";
                    }
                    if (data.teacher[arr].time8) {
                        time8 = "Busy";
                    }
                }
                else {
                    if (data.student[arr].time8) {
                        time8 = data.student[arr].time8;
                    }
                    if (data.room[arr].time8) {
                        time8 = "Busy";
                    }
                    if (data.rooml[arr].time8) {
                        time8 = "Busy";
                    }
                    if (data.teacher[arr].time8) {
                        time8 = "Busy";
                    }
                    if (data.student[arr].time8) {
                        time8 = "Busy";
                    }
                }
                if (time9 == null) {
                    time9 = "";
                    if (data.room[arr].time9) {
                        time9 = "Busy";
                    }
                    if (data.rooml[arr].time9) {
                        time9 = "Busy";
                    }
                    if (data.teacher[arr].time9) {
                        time9 = "Busy";
                    }
                }
                else {
                    if (data.student[arr].time9) {
                        time9 = data.student[arr].time9;
                    }
                    if (data.room[arr].time9) {
                        time9 = "Busy";
                    }
                    if (data.rooml[arr].time9) {
                        time9 = "Busy";
                    }
                    if (data.teacher[arr].time9) {
                        time9 = "Busy";
                    }
                    if (data.student[arr].time9) {
                        time9 = "Busy";
                    }
                }
                if (time10 == null) {
                    time10 = "";
                    if (data.room[arr].time10) {
                        time10 = "Busy";
                    }
                    if (data.rooml[arr].time10) {
                        time10 = "Busy";
                    }
                    if (data.teacher[arr].time10) {
                        time10 = "Busy";
                    }
                }
                else {
                    if (data.student[arr].time10) {
                        time10 = data.student[arr].time10;
                    }
                    if (data.room[arr].time10) {
                        time10 = "Busy";
                    }
                    if (data.rooml[arr].time10) {
                        time10 = "Busy";
                    }
                    if (data.teacher[arr].time10) {
                        time10 = "Busy";
                    }
                    if (data.student[arr].time10) {
                        time10 = "Busy";
                    }
                }
                if (time11 == null) {
                    time11 = "";
                    if (data.room[arr].time11) {
                        time11 = "Busy";
                    }
                    if (data.rooml[arr].time11) {
                        time11 = "Busy";
                    }
                    if (data.teacher[arr].time11) {
                        time11 = "Busy";
                    }
                }
                else {
                    if (data.student[arr].time11) {
                        time11 = data.student[arr].time11;
                    }
                    if (data.room[arr].time11) {
                        time11 = "Busy";
                    }
                    if (data.rooml[arr].time11) {
                        time11 = "Busy";
                    }
                    if (data.teacher[arr].time11) {
                        time11 = "Busy";
                    }
                    if (data.student[arr].time11) {
                        time11 = "Busy";
                    }
                }
                if (time12 == null) {
                    time12 = "";
                    if (data.room[arr].time12) {
                        time12 = "Busy";
                    }
                    if (data.rooml[arr].time12) {
                        time12 = "Busy";
                    }
                    if (data.teacher[arr].time12) {
                        time12 = "Busy";
                    }
                }
                else {
                    if (data.student[arr].time12) {
                        time12 = data.student[arr].time12;
                    }
                    if (data.room[arr].time12) {
                        time12 = "Busy";
                    }
                    if (data.rooml[arr].time12) {
                        time12 = "Busy";
                    }
                    if (data.teacher[arr].time12) {
                        time12 = "Busy";
                    }
                    if (data.student[arr].time12) {
                        time12 = "Busy";
                    }
                }
                if (time13 == null) {
                    time13 = "";
                    if (data.room[arr].time13) {
                        time13 = "Busy";
                    }
                    if (data.rooml[arr].time13) {
                        time13 = "Busy";
                    }
                    if (data.teacher[arr].time13) {
                        time13 = "Busy";
                    }
                }
                else {
                    if (data.student[arr].time13) {
                        time13 = data.student[arr].time13;
                    }
                    if (data.room[arr].time13) {
                        time13 = "Busy";
                    }
                    if (data.rooml[arr].time13) {
                        time13 = "Busy";
                    }
                    if (data.teacher[arr].time13) {
                        time13 = "Busy";
                    }
                    if (data.student[arr].time13) {
                        time13 = "Busy";
                    }
                }
            }
            var SQL1 = `UPDATE display_timetable SET time1 = '${time1}', time2 = '${time2}', time3 = '${time3}', time4 = '${time4}', time5 = '${time5}', time6 = '${time6}', time7 = '${time7}', time8 = '${time8}', time9 = '${time9}', time10 = '${time10}', time11 = '${time11}', time12 = '${time12}', time13 = '${time13}'
            WHERE day_id = '${day_id}'`;
            await db.query(SQL1, [time1, time2, time3, time4, time5, time6, time7, time8, time9, time10, time11, time12, time13, day_id]);

            var selectSQL = `SELECT day.day_name,
            display_timetable.time1, display_timetable.time2, display_timetable.time3, display_timetable.time4,
            display_timetable.time5, display_timetable.time6, display_timetable.time7, display_timetable.time8,
            display_timetable.time9, display_timetable.time10, display_timetable.time11, display_timetable.time12,
            display_timetable.time13
            FROM day
            LEFT JOIN display_timetable ON display_timetable.day_id = day.day_id
            ORDER BY display_timetable.day_id`;
            await db.query(selectSQL, callback);

            var cs_time1; var cs_time2; var cs_time3;
            var cs_time4; var cs_time5; var cs_time6;
            var cs_time7; var cs_time8; var cs_time9;
            var cs_time10; var cs_time11; var cs_time12;
            var cs_time13;

            var ct_time1; var ct_time2; var ct_time3;
            var ct_time4; var ct_time5; var ct_time6;
            var ct_time7; var ct_time8; var ct_time9;
            var ct_time10; var ct_time11; var ct_time12;
            var ct_time13;

            var cr_time1; var cr_time2; var cr_time3;
            var cr_time4; var cr_time5; var cr_time6;
            var cr_time7; var cr_time8; var cr_time9;
            var cr_time10; var cr_time11; var cr_time12;
            var cr_time13;

            var crl_time1; var crl_time2; var crl_time3;
            var crl_time4; var crl_time5; var crl_time6;
            var crl_time7; var crl_time8; var crl_time9;
            var crl_time10; var crl_time11; var crl_time12;
            var crl_time13;

            for (let i = 0; i <= 6; i++) {
                if (data.student[i].time1) { cs_time1 = 1; } else { cs_time1 = 0; }
                if (data.student[i].time2) { cs_time2 = 1; } else { cs_time2 = 0; }
                if (data.student[i].time3) { cs_time3 = 1; } else { cs_time3 = 0; }
                if (data.student[i].time4) { cs_time4 = 1; } else { cs_time4 = 0; }
                if (data.student[i].time5) { cs_time5 = 1; } else { cs_time5 = 0; }
                if (data.student[i].time6) { cs_time6 = 1; } else { cs_time6 = 0; }
                if (data.student[i].time7) { cs_time7 = 1; } else { cs_time7 = 0; }
                if (data.student[i].time8) { cs_time8 = 1; } else { cs_time8 = 0; }
                if (data.student[i].time9) { cs_time9 = 1; } else { cs_time9 = 0; }
                if (data.student[i].time10) { cs_time10 = 1; } else { cs_time10 = 0; }
                if (data.student[i].time11) { cs_time11 = 1; } else { cs_time11 = 0; }
                if (data.student[i].time12) { cs_time12 = 1; } else { cs_time12 = 0; }
                if (data.student[i].time13) { cs_time13 = 1; } else { cs_time13 = 0; }

                if (data.teacher[i].time1) { ct_time1 = 1; } else { ct_time1 = 0; }
                if (data.teacher[i].time2) { ct_time2 = 1; } else { ct_time2 = 0; }
                if (data.teacher[i].time3) { ct_time3 = 1; } else { ct_time3 = 0; }
                if (data.teacher[i].time4) { ct_time4 = 1; } else { ct_time4 = 0; }
                if (data.teacher[i].time5) { ct_time5 = 1; } else { ct_time5 = 0; }
                if (data.teacher[i].time6) { ct_time6 = 1; } else { ct_time6 = 0; }
                if (data.teacher[i].time7) { ct_time7 = 1; } else { ct_time7 = 0; }
                if (data.teacher[i].time8) { ct_time8 = 1; } else { ct_time8 = 0; }
                if (data.teacher[i].time9) { ct_time9 = 1; } else { ct_time9 = 0; }
                if (data.teacher[i].time10) { ct_time10 = 1; } else { ct_time10 = 0; }
                if (data.teacher[i].time11) { ct_time11 = 1; } else { ct_time11 = 0; }
                if (data.teacher[i].time12) { ct_time12 = 1; } else { ct_time12 = 0; }
                if (data.teacher[i].time13) { ct_time13 = 1; } else { ct_time13 = 0; }

                if (data.room[i].time1) { cr_time1 = 1; } else { cr_time1 = 0; }
                if (data.room[i].time2) { cr_time2 = 1; } else { cr_time2 = 0; }
                if (data.room[i].time3) { cr_time3 = 1; } else { cr_time3 = 0; }
                if (data.room[i].time4) { cr_time4 = 1; } else { cr_time4 = 0; }
                if (data.room[i].time5) { cr_time5 = 1; } else { cr_time5 = 0; }
                if (data.room[i].time6) { cr_time6 = 1; } else { cr_time6 = 0; }
                if (data.room[i].time7) { cr_time7 = 1; } else { cr_time7 = 0; }
                if (data.room[i].time8) { cr_time8 = 1; } else { cr_time8 = 0; }
                if (data.room[i].time9) { cr_time9 = 1; } else { cr_time9 = 0; }
                if (data.room[i].time10) { cr_time10 = 1; } else { cr_time10 = 0; }
                if (data.room[i].time11) { cr_time11 = 1; } else { cr_time11 = 0; }
                if (data.room[i].time12) { cr_time12 = 1; } else { cr_time12 = 0; }
                if (data.room[i].time13) { cr_time13 = 1; } else { cr_time13 = 0; }

                if (data.rooml[i].time1) { crl_time1 = 1; } else { crl_time1 = 0; }
                if (data.rooml[i].time2) { crl_time2 = 1; } else { crl_time2 = 0; }
                if (data.rooml[i].time3) { crl_time3 = 1; } else { crl_time3 = 0; }
                if (data.rooml[i].time4) { crl_time4 = 1; } else { crl_time4 = 0; }
                if (data.rooml[i].time5) { crl_time5 = 1; } else { crl_time5 = 0; }
                if (data.rooml[i].time6) { crl_time6 = 1; } else { crl_time6 = 0; }
                if (data.rooml[i].time7) { crl_time7 = 1; } else { crl_time7 = 0; }
                if (data.rooml[i].time8) { crl_time8 = 1; } else { crl_time8 = 0; }
                if (data.rooml[i].time9) { crl_time9 = 1; } else { crl_time9 = 0; }
                if (data.rooml[i].time10) { crl_time10 = 1; } else { crl_time10 = 0; }
                if (data.rooml[i].time11) { crl_time11 = 1; } else { crl_time11 = 0; }
                if (data.rooml[i].time12) { crl_time12 = 1; } else { crl_time12 = 0; }
                if (data.rooml[i].time13) { crl_time13 = 1; } else { crl_time13 = 0; }

                var day = parseInt([i]) + 1;

                var ns_time1 = parseInt(cs_time1);
                var ns_time2 = parseInt(cs_time2);
                var ns_time3 = parseInt(cs_time3);
                var ns_time4 = parseInt(cs_time4);
                var ns_time5 = parseInt(cs_time5);
                var ns_time6 = parseInt(cs_time6);
                var ns_time7 = parseInt(cs_time7);
                var ns_time8 = parseInt(cs_time8);
                var ns_time9 = parseInt(cs_time9);
                var ns_time10 = parseInt(cs_time10);
                var ns_time11 = parseInt(cs_time11);
                var ns_time12 = parseInt(cs_time12);
                var ns_time13 = parseInt(cs_time13);

                var nt_time1 = parseInt(ct_time1);
                var nt_time2 = parseInt(ct_time2);
                var nt_time3 = parseInt(ct_time3);
                var nt_time4 = parseInt(ct_time4);
                var nt_time5 = parseInt(ct_time5);
                var nt_time6 = parseInt(ct_time6);
                var nt_time7 = parseInt(ct_time7);
                var nt_time8 = parseInt(ct_time8);
                var nt_time9 = parseInt(ct_time9);
                var nt_time10 = parseInt(ct_time10);
                var nt_time11 = parseInt(ct_time11);
                var nt_time12 = parseInt(ct_time12);
                var nt_time13 = parseInt(ct_time13);

                var nr_time1 = parseInt(cr_time1);
                var nr_time2 = parseInt(cr_time2);
                var nr_time3 = parseInt(cr_time3);
                var nr_time4 = parseInt(cr_time4);
                var nr_time5 = parseInt(cr_time5);
                var nr_time6 = parseInt(cr_time6);
                var nr_time7 = parseInt(cr_time7);
                var nr_time8 = parseInt(cr_time8);
                var nr_time9 = parseInt(cr_time9);
                var nr_time10 = parseInt(cr_time10);
                var nr_time11 = parseInt(cr_time11);
                var nr_time12 = parseInt(cr_time12);
                var nr_time13 = parseInt(cr_time13);

                var nrl_time1 = parseInt(crl_time1);
                var nrl_time2 = parseInt(crl_time2);
                var nrl_time3 = parseInt(crl_time3);
                var nrl_time4 = parseInt(crl_time4);
                var nrl_time5 = parseInt(crl_time5);
                var nrl_time6 = parseInt(crl_time6);
                var nrl_time7 = parseInt(crl_time7);
                var nrl_time8 = parseInt(crl_time8);
                var nrl_time9 = parseInt(crl_time9);
                var nrl_time10 = parseInt(crl_time10);
                var nrl_time11 = parseInt(crl_time11);
                var nrl_time12 = parseInt(crl_time12);
                var nrl_time13 = parseInt(crl_time13);

                var d_time1 = ns_time1 || nt_time1 || nr_time1 || nrl_time1;
                var d_time2 = ns_time2 || nt_time2 || nr_time2 || nrl_time2;
                var d_time3 = ns_time3 || nt_time3 || nr_time3 || nrl_time3;
                var d_time4 = ns_time4 || nt_time4 || nr_time4 || nrl_time4;
                var d_time5 = ns_time5 || nt_time5 || nr_time5 || nrl_time5;
                var d_time6 = ns_time6 || nt_time6 || nr_time6 || nrl_time6;
                var d_time7 = ns_time7 || nt_time7 || nr_time7 || nrl_time7;
                var d_time8 = ns_time8 || nt_time8 || nr_time8 || nrl_time8;
                var d_time9 = ns_time9 || nt_time9 || nr_time9 || nrl_time9;
                var d_time10 = ns_time10 || nt_time10 || nr_time10 || nrl_time10;
                var d_time11 = ns_time11 || nt_time11 || nr_time11 || nrl_time11;
                var d_time12 = ns_time12 || nt_time12 || nr_time12 || nrl_time12;
                var d_time13 = ns_time13 || nt_time13 || nr_time13 || nrl_time13;

                if (d_time1 == 0) { d_time1 = 0; } else { d_time1 = 1 }
                if (d_time2 == 0) { d_time2 = 0; } else { d_time2 = 1 }
                if (d_time3 == 0) { d_time3 = 0; } else { d_time3 = 1 }
                if (d_time4 == 0) { d_time4 = 0; } else { d_time4 = 1 }
                if (d_time5 == 0) { d_time5 = 0; } else { d_time5 = 1 }
                if (d_time6 == 0) { d_time6 = 0; } else { d_time6 = 1 }
                if (d_time7 == 0) { d_time7 = 0; } else { d_time7 = 1 }
                if (d_time8 == 0) { d_time8 = 0; } else { d_time8 = 1 }
                if (d_time9 == 0) { d_time9 = 0; } else { d_time9 = 1 }
                if (d_time10 == 0) { d_time10 = 0; } else { d_time10 = 1 }
                if (d_time11 == 0) { d_time11 = 0; } else { d_time11 = 1 }
                if (d_time12 == 0) { d_time12 = 0; } else { d_time12 = 1 }
                if (d_time13 == 0) { d_time13 = 0; } else { d_time13 = 1 }

                var SQL9 = `UPDATE display_timetable SET time1 = '${d_time1}', time2 = '${d_time2}', time3 = '${d_time3}', time4 = '${d_time4}', time5 = '${d_time5}', time6 = '${d_time6}', time7 = '${d_time7}', time8 = '${d_time8}', time9 = '${d_time9}', time10 = '${d_time10}', time11 = '${d_time11}', time12 = '${d_time12}', time13 = '${d_time13}'
                WHERE day_id = '${day}'`;
                await db.query(SQL9, [d_time1, d_time2, d_time3, d_time4, d_time5, d_time6, d_time7, d_time8, d_time9, d_time10, d_time11, d_time12, d_time13, day]);
            }
        }
    },

    // update timetable
    updateTimetable: async function (data, callback) {
        var term_id = data.term_id;
        var year_id = data.year_id;
        var day_id = data.day_id;
        var student_groups_name = data.student_groups_name;

        var time1; var time2; var time3;
        var time4; var time5; var time6;
        var time7; var time8; var time9;
        var time10; var time11; var time12;
        var time13;

        var timet1; var timet2; var timet3;
        var timet4; var timet5; var timet6;
        var timet7; var timet8; var timet9;
        var timet10; var timet11; var timet12;
        var timet13;

        var timel1; var timel2; var timel3;
        var timel4; var timel5; var timel6;
        var timel7; var timel8; var timel9;
        var timel10; var timel11; var timel12;
        var timel13;

        var subject_name = data.subject_name;
        var subject_unit = data.subject_unit;
        var subject_id = data.subject_id;
        var room_id = data.room_id;
        var rooml_id = data.rooml_id;
        var student_groups_id = data.student_groups_id;
        var teacher_id = data.teacher_id;

        var sum;
        var sumTotal = 0;

        var input = subject_unit;
        var output1 = input.substring(2, 3);
        var output2 = input.substring(4, 5);
        var a = parseInt(output1) // T
        var b = parseInt(output2) // L
        console.log("Theory", output1, "Lab", output2)
        var time = data.time;
        var time = parseInt(data.time)
        var column = time;
        var timet_s = parseInt(column);
        var timet_e = parseInt(column + a - 1);
        var timel_s = parseInt(column + a);
        var timel_e = parseInt(column + a + b - 1);
        console.log("time_start", timet_s, "time_end", timel_e);
        console.log("time_t_start", timet_s, "time_t_end", timet_e);
        console.log("time_l_start", timel_s, "time_l_end", timel_e);
        if (day_id == 1) {
            for (var i = timet_s; i <= timel_e; i++) {
                switch (i) {
                    case 1: sum = parseInt(data.display[0].time1); break;
                    case 2: sum = parseInt(data.display[0].time2); break;
                    case 3: sum = parseInt(data.display[0].time3); break;
                    case 4: sum = parseInt(data.display[0].time4); break;
                    case 5: sum = parseInt(data.display[0].time5); break;
                    case 6: sum = parseInt(data.display[0].time6); break;
                    case 7: sum = parseInt(data.display[0].time7); break;
                    case 8: sum = parseInt(data.display[0].time8); break;
                    case 9: sum = parseInt(data.display[0].time9); break;
                    case 10: sum = parseInt(data.display[0].time10); break;
                    case 11: sum = parseInt(data.display[0].time11); break;
                    case 12: sum = parseInt(data.display[0].time12); break;
                    case 13: sum = parseInt(data.display[0].time13); break;
                }
                sumTotal = parseInt(sumTotal) + parseInt(sum);
            }
        }
        if (day_id == 2) {
            for (var i = timet_s; i <= timel_e; i++) {
                switch (i) {
                    case 1: sum = parseInt(data.display[1].time1); break;
                    case 2: sum = parseInt(data.display[1].time2); break;
                    case 3: sum = parseInt(data.display[1].time3); break;
                    case 4: sum = parseInt(data.display[1].time4); break;
                    case 5: sum = parseInt(data.display[1].time5); break;
                    case 6: sum = parseInt(data.display[1].time6); break;
                    case 7: sum = parseInt(data.display[1].time7); break;
                    case 8: sum = parseInt(data.display[1].time8); break;
                    case 9: sum = parseInt(data.display[1].time9); break;
                    case 10: sum = parseInt(data.display[1].time10); break;
                    case 11: sum = parseInt(data.display[1].time11); break;
                    case 12: sum = parseInt(data.display[1].time12); break;
                    case 13: sum = parseInt(data.display[1].time13); break;
                }
                sumTotal = parseInt(sumTotal) + parseInt(sum);
            }
        }
        if (day_id == 3) {
            for (var i = timet_s; i <= timel_e; i++) {
                switch (i) {
                    case 1: sum = parseInt(data.display[2].time1); break;
                    case 2: sum = parseInt(data.display[2].time2); break;
                    case 3: sum = parseInt(data.display[2].time3); break;
                    case 4: sum = parseInt(data.display[2].time4); break;
                    case 5: sum = parseInt(data.display[2].time5); break;
                    case 6: sum = parseInt(data.display[2].time6); break;
                    case 7: sum = parseInt(data.display[2].time7); break;
                    case 8: sum = parseInt(data.display[2].time8); break;
                    case 9: sum = parseInt(data.display[2].time9); break;
                    case 10: sum = parseInt(data.display[2].time10); break;
                    case 11: sum = parseInt(data.display[2].time11); break;
                    case 12: sum = parseInt(data.display[2].time12); break;
                    case 13: sum = parseInt(data.display[2].time13); break;
                }
                sumTotal = parseInt(sumTotal) + parseInt(sum);
            }
        }
        if (day_id == 4) {
            for (var i = timet_s; i <= timel_e; i++) {
                switch (i) {
                    case 1: sum = parseInt(data.display[3].time1); break;
                    case 2: sum = parseInt(data.display[3].time2); break;
                    case 3: sum = parseInt(data.display[3].time3); break;
                    case 4: sum = parseInt(data.display[3].time4); break;
                    case 5: sum = parseInt(data.display[3].time5); break;
                    case 6: sum = parseInt(data.display[3].time6); break;
                    case 7: sum = parseInt(data.display[3].time7); break;
                    case 8: sum = parseInt(data.display[3].time8); break;
                    case 9: sum = parseInt(data.display[3].time9); break;
                    case 10: sum = parseInt(data.display[3].time10); break;
                    case 11: sum = parseInt(data.display[3].time11); break;
                    case 12: sum = parseInt(data.display[3].time12); break;
                    case 13: sum = parseInt(data.display[3].time13); break;
                }
                sumTotal = parseInt(sumTotal) + parseInt(sum);
            }
        }
        if (day_id == 5) {
            for (var i = timet_s; i <= timel_e; i++) {
                switch (i) {
                    case 1: sum = parseInt(data.display[4].time1); break;
                    case 2: sum = parseInt(data.display[4].time2); break;
                    case 3: sum = parseInt(data.display[4].time3); break;
                    case 4: sum = parseInt(data.display[4].time4); break;
                    case 5: sum = parseInt(data.display[4].time5); break;
                    case 6: sum = parseInt(data.display[4].time6); break;
                    case 7: sum = parseInt(data.display[4].time7); break;
                    case 8: sum = parseInt(data.display[4].time8); break;
                    case 9: sum = parseInt(data.display[4].time9); break;
                    case 10: sum = parseInt(data.display[4].time10); break;
                    case 11: sum = parseInt(data.display[4].time11); break;
                    case 12: sum = parseInt(data.display[4].time12); break;
                    case 13: sum = parseInt(data.display[4].time13); break;
                }
                sumTotal = parseInt(sumTotal) + parseInt(sum);
            }
        }
        if (day_id == 6) {
            for (var i = timet_s; i <= timel_e; i++) {
                switch (i) {
                    case 1: sum = parseInt(data.display[5].time1); break;
                    case 2: sum = parseInt(data.display[5].time2); break;
                    case 3: sum = parseInt(data.display[5].time3); break;
                    case 4: sum = parseInt(data.display[5].time4); break;
                    case 5: sum = parseInt(data.display[5].time5); break;
                    case 6: sum = parseInt(data.display[5].time6); break;
                    case 7: sum = parseInt(data.display[5].time7); break;
                    case 8: sum = parseInt(data.display[5].time8); break;
                    case 9: sum = parseInt(data.display[5].time9); break;
                    case 10: sum = parseInt(data.display[5].time10); break;
                    case 11: sum = parseInt(data.display[5].time11); break;
                    case 12: sum = parseInt(data.display[5].time12); break;
                    case 13: sum = parseInt(data.display[5].time13); break;
                }
                sumTotal = parseInt(sumTotal) + parseInt(sum);
            }
        }
        if (day_id == 7) {
            for (var i = timet_s; i <= timel_e; i++) {
                switch (i) {
                    case 1: sum = parseInt(data.display[6].time1); break;
                    case 2: sum = parseInt(data.display[6].time2); break;
                    case 3: sum = parseInt(data.display[6].time3); break;
                    case 4: sum = parseInt(data.display[6].time4); break;
                    case 5: sum = parseInt(data.display[6].time5); break;
                    case 6: sum = parseInt(data.display[6].time6); break;
                    case 7: sum = parseInt(data.display[6].time7); break;
                    case 8: sum = parseInt(data.display[6].time8); break;
                    case 9: sum = parseInt(data.display[6].time9); break;
                    case 10: sum = parseInt(data.display[6].time10); break;
                    case 11: sum = parseInt(data.display[6].time11); break;
                    case 12: sum = parseInt(data.display[6].time12); break;
                    case 13: sum = parseInt(data.display[6].time13); break;
                }
                sumTotal = parseInt(sumTotal) + parseInt(sum);
            }
        }


        if (teacher_id && room_id && rooml_id && student_groups_name) {
            for (var i = timet_s; i <= timel_e; i++) {
                switch (i) {
                    case 1: time1 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 2: time2 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 3: time3 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 4: time4 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 5: time5 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 6: time6 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 7: time7 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 8: time8 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 9: time9 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 10: time10 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 11: time11 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 12: time12 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 13: time13 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                }

                var arr = parseInt(day_id) - 1;
                if (time1 == null) {
                    time1 = data.student[arr].time1;
                    if (time1 == null) {
                        time1 = "";
                    }
                }
                if (time2 == null) {
                    time2 = data.student[arr].time2;
                    if (time2 == null) {
                        time2 = "";
                    }
                }
                if (time3 == null) {
                    time3 = data.student[arr].time3;
                    if (time3 == null) {
                        time3 = "";
                    }
                }
                if (time4 == null) {
                    time4 = data.student[arr].time4;
                    if (time4 == null) {
                        time4 = "";
                    }
                }
                if (time5 == null) {
                    time5 = data.student[arr].time5;
                    if (time5 == null) {
                        time5 = "";
                    }
                }
                if (time6 == null) {
                    time6 = data.student[arr].time6;
                    if (time6 == null) {
                        time6 = "";
                    }
                }
                if (time7 == null) {
                    time7 = data.student[arr].time7;
                    if (time7 == null) {
                        time7 = "";
                    }
                }
                if (time8 == null) {
                    time8 = data.student[arr].time8;
                    if (time8 == null) {
                        time8 = "";
                    }
                }
                if (time9 == null) {
                    time9 = data.student[arr].time9;
                    if (time9 == null) {
                        time9 = "";
                    }
                }
                if (time10 == null) {
                    time10 = data.student[arr].time10;
                    if (time10 == null) {
                        time10 = "";
                    }
                }
                if (time11 == null) {
                    time11 = data.student[arr].time11;
                    if (time11 == null) {
                        time11 = "";
                    }
                }
                if (time12 == null) {
                    time12 = data.student[arr].time12;
                    if (time12 == null) {
                        time12 = "";
                    }
                }
                if (time13 == null) {
                    time13 = data.student[arr].time13;
                    if (time13 == null) {
                        time13 = "";
                    }
                }
            }

            for (var i = timet_s; i <= timet_e; i++) {
                switch (i) {
                    case 1: timet1 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 2: timet2 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 3: timet3 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 4: timet4 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 5: timet5 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 6: timet6 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 7: timet7 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 8: timet8 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 9: timet9 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 10: timet10 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 11: timet11 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 12: timet12 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 13: timet13 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                }



                if (timet1 == null) {
                    timet1 = data.student[arr].time1;
                    if (timet1 == null) {
                        timet1 = "";
                    }
                }
                if (timet2 == null) {
                    timet2 = data.student[arr].time2;
                    if (timet2 == null) {
                        timet2 = "";
                    }
                }
                if (timet3 == null) {
                    timet3 = data.student[arr].time3;
                    if (timet3 == null) {
                        timet3 = "";
                    }
                }
                if (timet4 == null) {
                    timet4 = data.student[arr].time4;
                    if (timet4 == null) {
                        timet4 = "";
                    }
                }
                if (timet5 == null) {
                    timet5 = data.student[arr].time5;
                    if (timet5 == null) {
                        timet5 = "";
                    }
                }
                if (timet6 == null) {
                    timet6 = data.student[arr].time6;
                    if (timet6 == null) {
                        timet6 = "";
                    }
                }
                if (timet7 == null) {
                    timet7 = data.student[arr].time7;
                    if (timet7 == null) {
                        timet7 = "";
                    }
                }
                if (timet8 == null) {
                    timet8 = data.student[arr].time8;
                    if (timet8 == null) {
                        timet8 = "";
                    }
                }
                if (timet9 == null) {
                    timet9 = data.student[arr].time9;
                    if (timet9 == null) {
                        timet9 = "";
                    }
                }
                if (timet10 == null) {
                    timet10 = data.student[arr].time10;
                    if (timet10 == null) {
                        timet10 = "";
                    }
                }
                if (timet11 == null) {
                    timet11 = data.student[arr].time11;
                    if (timet11 == null) {
                        timet11 = "";
                    }
                }
                if (timet12 == null) {
                    timet12 = data.student[arr].time12;
                    if (timet12 == null) {
                        timet12 = "";
                    }
                }
                if (timet13 == null) {
                    timet13 = data.student[arr].time13;
                    if (timet13 == null) {
                        timet13 = "";
                    }
                }
            }

            for (var i = timel_s; i <= timel_e; i++) {
                switch (i) {
                    case 1: timel1 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 2: timel2 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 3: timel3 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 4: timel4 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 5: timel5 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 6: timel6 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 7: timel7 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 8: timel8 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 9: timel9 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 10: timel10 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 11: timel11 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 12: timel12 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 13: timel13 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                }

                var arr = parseInt(day_id) - 1;
                if (timel1 == null) {
                    timel1 = data.student[arr].time1;
                    if (timel1 == null) {
                        timel1 = "";
                    }
                }
                if (timel2 == null) {
                    timel2 = data.student[arr].time2;
                    if (timel2 == null) {
                        timel2 = "";
                    }
                }
                if (timel3 == null) {
                    timel3 = data.student[arr].time3;
                    if (timel3 == null) {
                        timel3 = "";
                    }
                }
                if (timel4 == null) {
                    timel4 = data.student[arr].time4;
                    if (timel4 == null) {
                        timel4 = "";
                    }
                }
                if (timel5 == null) {
                    timel5 = data.student[arr].time5;
                    if (timel5 == null) {
                        timel5 = "";
                    }
                }
                if (timel6 == null) {
                    timel6 = data.student[arr].time6;
                    if (timel6 == null) {
                        timel6 = "";
                    }
                }
                if (timel7 == null) {
                    timel7 = data.student[arr].time7;
                    if (timel7 == null) {
                        timel7 = "";
                    }
                }
                if (timel8 == null) {
                    timel8 = data.student[arr].time8;
                    if (timel8 == null) {
                        timel8 = "";
                    }
                }
                if (timel9 == null) {
                    timel9 = data.student[arr].time9;
                    if (timel9 == null) {
                        timel9 = "";
                    }
                }
                if (timel10 == null) {
                    timel10 = data.student[arr].time10;
                    if (timel10 == null) {
                        timel10 = "";
                    }
                }
                if (timel11 == null) {
                    timel11 = data.student[arr].time11;
                    if (timel11 == null) {
                        timel11 = "";
                    }
                }
                if (timel12 == null) {
                    timel12 = data.student[arr].time12;
                    if (timel12 == null) {
                        timel12 = "";
                    }
                }
                if (timel13 == null) {
                    timel13 = data.student[arr].time13;
                    if (timel13 == null) {
                        timel13 = "";
                    }
                }
            }
        }

        if (teacher_id && room_id && !rooml_id && student_groups_name) {
            for (var i = timet_s; i <= timel_e; i++) {
                switch (i) {
                    case 1: time1 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 2: time2 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 3: time3 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 4: time4 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 5: time5 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 6: time6 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 7: time7 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 8: time8 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 9: time9 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 10: time10 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 11: time11 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 12: time12 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 13: time13 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                }


                var arr = parseInt(day_id) - 1;
                if (time1 == null) {
                    time1 = data.student[arr].time1;
                    if (time1 == null) {
                        time1 = "";
                    }
                }
                if (time2 == null) {
                    time2 = data.student[arr].time2;
                    if (time2 == null) {
                        time2 = "";
                    }
                }
                if (time3 == null) {
                    time3 = data.student[arr].time3;
                    if (time3 == null) {
                        time3 = "";
                    }
                }
                if (time4 == null) {
                    time4 = data.student[arr].time4;
                    if (time4 == null) {
                        time4 = "";
                    }
                }
                if (time5 == null) {
                    time5 = data.student[arr].time5;
                    if (time5 == null) {
                        time5 = "";
                    }
                }
                if (time6 == null) {
                    time6 = data.student[arr].time6;
                    if (time6 == null) {
                        time6 = "";
                    }
                }
                if (time7 == null) {
                    time7 = data.student[arr].time7;
                    if (time7 == null) {
                        time7 = "";
                    }
                }
                if (time8 == null) {
                    time8 = data.student[arr].time8;
                    if (time8 == null) {
                        time8 = "";
                    }
                }
                if (time9 == null) {
                    time9 = data.student[arr].time9;
                    if (time9 == null) {
                        time9 = "";
                    }
                }
                if (time10 == null) {
                    time10 = data.student[arr].time10;
                    if (time10 == null) {
                        time10 = "";
                    }
                }
                if (time11 == null) {
                    time11 = data.student[arr].time11;
                    if (time11 == null) {
                        time11 = "";
                    }
                }
                if (time12 == null) {
                    time12 = data.student[arr].time12;
                    if (time12 == null) {
                        time12 = "";
                    }
                }
                if (time13 == null) {
                    time13 = data.student[arr].time13;
                    if (time13 == null) {
                        time13 = "";
                    }
                }
            }

            for (var i = timet_s; i <= timet_e; i++) {
                switch (i) {
                    case 1: timet1 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 2: timet2 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 3: timet3 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 4: timet4 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 5: timet5 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 6: timet6 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 7: timet7 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 8: timet8 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 9: timet9 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 10: timet10 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 11: timet11 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 12: timet12 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 13: timet13 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                }


                var arr = parseInt(day_id) - 1;
                if (timet1 == null) {
                    timet1 = data.student[arr].time1;
                    if (timet1 == null) {
                        timet1 = "";
                    }
                }
                if (timet2 == null) {
                    timet2 = data.student[arr].time2;
                    if (timet2 == null) {
                        timet2 = "";
                    }
                }
                if (timet3 == null) {
                    timet3 = data.student[arr].time3;
                    if (timet3 == null) {
                        timet3 = "";
                    }
                }
                if (timet4 == null) {
                    timet4 = data.student[arr].time4;
                    if (timet4 == null) {
                        timet4 = "";
                    }
                }
                if (timet5 == null) {
                    timet5 = data.student[arr].time5;
                    if (timet5 == null) {
                        timet5 = "";
                    }
                }
                if (timet6 == null) {
                    timet6 = data.student[arr].time6;
                    if (timet6 == null) {
                        timet6 = "";
                    }
                }
                if (timet7 == null) {
                    timet7 = data.student[arr].time7;
                    if (timet7 == null) {
                        timet7 = "";
                    }
                }
                if (timet8 == null) {
                    timet8 = data.student[arr].time8;
                    if (timet8 == null) {
                        timet8 = "";
                    }
                }
                if (timet9 == null) {
                    timet9 = data.student[arr].time9;
                    if (timet9 == null) {
                        timet9 = "";
                    }
                }
                if (timet10 == null) {
                    timet10 = data.student[arr].time10;
                    if (timet10 == null) {
                        timet10 = "";
                    }
                }
                if (timet11 == null) {
                    timet11 = data.student[arr].time11;
                    if (timet11 == null) {
                        timet11 = "";
                    }
                }
                if (timet12 == null) {
                    timet12 = data.student[arr].time12;
                    if (timet12 == null) {
                        timet12 = "";
                    }
                }
                if (timet13 == null) {
                    timet13 = data.student[arr].time13;
                    if (timet13 == null) {
                        timet13 = "";
                    }
                }
            }

            for (var i = timel_s; i <= timel_e; i++) {
                switch (i) {
                    case 1: timel1 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 2: timel2 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 3: timel3 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 4: timel4 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 5: timel5 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 6: timel6 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 7: timel7 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 8: timel8 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 9: timel9 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 10: timel10 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 11: timel11 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 12: timel12 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                    case 13: timel13 = subject_name + ' | ' + teacher_id + ' | ' + room_id + ' | ' + student_groups_name; break;
                }

                var arr = parseInt(day_id) - 1;
                if (timel1 == null) {
                    timel1 = data.student[arr].time1;
                    if (timel1 == null) {
                        timel1 = "";
                    }
                }
                if (timel2 == null) {
                    timel2 = data.student[arr].time2;
                    if (timel2 == null) {
                        timel2 = "";
                    }
                }
                if (timel3 == null) {
                    timel3 = data.student[arr].time3;
                    if (timel3 == null) {
                        timel3 = "";
                    }
                }
                if (timel4 == null) {
                    timel4 = data.student[arr].time4;
                    if (timel4 == null) {
                        timel4 = "";
                    }
                }
                if (timel5 == null) {
                    timel5 = data.student[arr].time5;
                    if (timel5 == null) {
                        timel5 = "";
                    }
                }
                if (timel6 == null) {
                    timel6 = data.student[arr].time6;
                    if (timel6 == null) {
                        timel6 = "";
                    }
                }
                if (timel7 == null) {
                    timel7 = data.student[arr].time7;
                    if (timel7 == null) {
                        timel7 = "";
                    }
                }
                if (timel8 == null) {
                    timel8 = data.student[arr].time8;
                    if (timel8 == null) {
                        timel8 = "";
                    }
                }
                if (timel9 == null) {
                    timel9 = data.student[arr].time9;
                    if (timel9 == null) {
                        timel9 = "";
                    }
                }
                if (timel10 == null) {
                    timel10 = data.student[arr].time10;
                    if (timel10 == null) {
                        timel10 = "";
                    }
                }
                if (timel11 == null) {
                    timel11 = data.student[arr].time11;
                    if (timel11 == null) {
                        timel11 = "";
                    }
                }
                if (timel12 == null) {
                    timel12 = data.student[arr].time12;
                    if (timel12 == null) {
                        timel12 = "";
                    }
                }
                if (timel13 == null) {
                    timel13 = data.student[arr].time13;
                    if (timel13 == null) {
                        timel13 = "";
                    }
                }
            }
        }

        if (teacher_id && !room_id && rooml_id && student_groups_name) {
            for (var i = timet_s; i <= timel_e; i++) {
                switch (i) {
                    case 1: time1 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 2: time2 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 3: time3 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 4: time4 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 5: time5 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 6: time6 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 7: time7 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 8: time8 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 9: time9 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 10: time10 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 11: time11 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 12: time12 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 13: time13 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                }


                var arr = parseInt(day_id) - 1;
                if (time1 == null) {
                    time1 = data.student[arr].time1;
                    if (time1 == null) {
                        time1 = "";
                    }
                }
                if (time2 == null) {
                    time2 = data.student[arr].time2;
                    if (time2 == null) {
                        time2 = "";
                    }
                }
                if (time3 == null) {
                    time3 = data.student[arr].time3;
                    if (time3 == null) {
                        time3 = "";
                    }
                }
                if (time4 == null) {
                    time4 = data.student[arr].time4;
                    if (time4 == null) {
                        time4 = "";
                    }
                }
                if (time5 == null) {
                    time5 = data.student[arr].time5;
                    if (time5 == null) {
                        time5 = "";
                    }
                }
                if (time6 == null) {
                    time6 = data.student[arr].time6;
                    if (time6 == null) {
                        time6 = "";
                    }
                }
                if (time7 == null) {
                    time7 = data.student[arr].time7;
                    if (time7 == null) {
                        time7 = "";
                    }
                }
                if (time8 == null) {
                    time8 = data.student[arr].time8;
                    if (time8 == null) {
                        time8 = "";
                    }
                }
                if (time9 == null) {
                    time9 = data.student[arr].time9;
                    if (time9 == null) {
                        time9 = "";
                    }
                }
                if (time10 == null) {
                    time10 = data.student[arr].time10;
                    if (time10 == null) {
                        time10 = "";
                    }
                }
                if (time11 == null) {
                    time11 = data.student[arr].time11;
                    if (time11 == null) {
                        time11 = "";
                    }
                }
                if (time12 == null) {
                    time12 = data.student[arr].time12;
                    if (time12 == null) {
                        time12 = "";
                    }
                }
                if (time13 == null) {
                    time13 = data.student[arr].time13;
                    if (time13 == null) {
                        time13 = "";
                    }
                }
            }

            for (var i = timet_s; i <= timet_e; i++) {
                switch (i) {
                    case 1: timet1 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 2: timet2 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 3: timet3 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 4: timet4 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 5: timet5 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 6: timet6 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 7: timet7 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 8: timet8 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 9: timet9 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 10: timet10 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 11: timet11 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 12: timet12 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 13: timet13 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                }


                var arr = parseInt(day_id) - 1;
                if (timet1 == null) {
                    timet1 = data.student[arr].time1;
                    if (timet1 == null) {
                        timet1 = "";
                    }
                }
                if (timet2 == null) {
                    timet2 = data.student[arr].time2;
                    if (timet2 == null) {
                        timet2 = "";
                    }
                }
                if (timet3 == null) {
                    timet3 = data.student[arr].time3;
                    if (timet3 == null) {
                        timet3 = "";
                    }
                }
                if (timet4 == null) {
                    timet4 = data.student[arr].time4;
                    if (timet4 == null) {
                        timet4 = "";
                    }
                }
                if (timet5 == null) {
                    timet5 = data.student[arr].time5;
                    if (timet5 == null) {
                        timet5 = "";
                    }
                }
                if (timet6 == null) {
                    timet6 = data.student[arr].time6;
                    if (timet6 == null) {
                        timet6 = "";
                    }
                }
                if (timet7 == null) {
                    timet7 = data.student[arr].time7;
                    if (timet7 == null) {
                        timet7 = "";
                    }
                }
                if (timet8 == null) {
                    timet8 = data.student[arr].time8;
                    if (timet8 == null) {
                        timet8 = "";
                    }
                }
                if (timet9 == null) {
                    timet9 = data.student[arr].time9;
                    if (timet9 == null) {
                        timet9 = "";
                    }
                }
                if (timet10 == null) {
                    timet10 = data.student[arr].time10;
                    if (timet10 == null) {
                        timet10 = "";
                    }
                }
                if (timet11 == null) {
                    timet11 = data.student[arr].time11;
                    if (timet11 == null) {
                        timet11 = "";
                    }
                }
                if (timet12 == null) {
                    timet12 = data.student[arr].time12;
                    if (timet12 == null) {
                        timet12 = "";
                    }
                }
                if (timet13 == null) {
                    timet13 = data.student[arr].time13;
                    if (timet13 == null) {
                        timet13 = "";
                    }
                }
            }

            for (var i = timel_s; i <= timel_e; i++) {
                switch (i) {
                    case 1: timel1 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 2: timel2 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 3: timel3 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 4: timel4 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 5: timel5 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 6: timel6 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 7: timel7 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 8: timel8 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 9: timel9 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 10: timel10 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 11: timel11 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 12: timel12 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                    case 13: timel13 = subject_name + ' | ' + teacher_id + ' | ' + rooml_id + ' | ' + student_groups_name; break;
                }

                var arr = parseInt(day_id) - 1;
                if (timel1 == null) {
                    timel1 = data.student[arr].time1;
                    if (timel1 == null) {
                        timel1 = "";
                    }
                }
                if (timel2 == null) {
                    timel2 = data.student[arr].time2;
                    if (timel2 == null) {
                        timel2 = "";
                    }
                }
                if (timel3 == null) {
                    timel3 = data.student[arr].time3;
                    if (timel3 == null) {
                        timel3 = "";
                    }
                }
                if (timel4 == null) {
                    timel4 = data.student[arr].time4;
                    if (timel4 == null) {
                        timel4 = "";
                    }
                }
                if (timel5 == null) {
                    timel5 = data.student[arr].time5;
                    if (timel5 == null) {
                        timel5 = "";
                    }
                }
                if (timel6 == null) {
                    timel6 = data.student[arr].time6;
                    if (timel6 == null) {
                        timel6 = "";
                    }
                }
                if (timel7 == null) {
                    timel7 = data.student[arr].time7;
                    if (timel7 == null) {
                        timel7 = "";
                    }
                }
                if (timel8 == null) {
                    timel8 = data.student[arr].time8;
                    if (timel8 == null) {
                        timel8 = "";
                    }
                }
                if (timel9 == null) {
                    timel9 = data.student[arr].time9;
                    if (timel9 == null) {
                        timel9 = "";
                    }
                }
                if (timel10 == null) {
                    timel10 = data.student[arr].time10;
                    if (timel10 == null) {
                        timel10 = "";
                    }
                }
                if (timel11 == null) {
                    timel11 = data.student[arr].time11;
                    if (timel11 == null) {
                        timel11 = "";
                    }
                }
                if (timel12 == null) {
                    timel12 = data.student[arr].time12;
                    if (timel12 == null) {
                        timel12 = "";
                    }
                }
                if (timel13 == null) {
                    timel13 = data.student[arr].time13;
                    if (timel13 == null) {
                        timel13 = "";
                    }
                }
            }
        }

        if (!teacher_id && !room_id && !rooml_id && student_groups_name) {
            for (var i = timet_s; i <= timel_e; i++) {
                switch (i) {
                    case 1: time1 = subject_name + ' | ' + student_groups_name; break;
                    case 2: time2 = subject_name + ' | ' + student_groups_name; break;
                    case 3: time3 = subject_name + ' | ' + student_groups_name; break;
                    case 4: time4 = subject_name + ' | ' + student_groups_name; break;
                    case 5: time5 = subject_name + ' | ' + student_groups_name; break;
                    case 6: time6 = subject_name + ' | ' + student_groups_name; break;
                    case 7: time7 = subject_name + ' | ' + student_groups_name; break;
                    case 8: time8 = subject_name + ' | ' + student_groups_name; break;
                    case 9: time9 = subject_name + ' | ' + student_groups_name; break;
                    case 10: time10 = subject_name + ' | ' + student_groups_name; break;
                    case 11: time11 = subject_name + ' | ' + student_groups_name; break;
                    case 12: time12 = subject_name + ' | ' + student_groups_name; break;
                    case 13: time13 = subject_name + ' | ' + student_groups_name; break;
                }


                var arr = parseInt(day_id) - 1;
                if (time1 == null) {
                    time1 = data.student[arr].time1;
                    if (time1 == null) {
                        time1 = "";
                    }
                }
                if (time2 == null) {
                    time2 = data.student[arr].time2;
                    if (time2 == null) {
                        time2 = "";
                    }
                }
                if (time3 == null) {
                    time3 = data.student[arr].time3;
                    if (time3 == null) {
                        time3 = "";
                    }
                }
                if (time4 == null) {
                    time4 = data.student[arr].time4;
                    if (time4 == null) {
                        time4 = "";
                    }
                }
                if (time5 == null) {
                    time5 = data.student[arr].time5;
                    if (time5 == null) {
                        time5 = "";
                    }
                }
                if (time6 == null) {
                    time6 = data.student[arr].time6;
                    if (time6 == null) {
                        time6 = "";
                    }
                }
                if (time7 == null) {
                    time7 = data.student[arr].time7;
                    if (time7 == null) {
                        time7 = "";
                    }
                }
                if (time8 == null) {
                    time8 = data.student[arr].time8;
                    if (time8 == null) {
                        time8 = "";
                    }
                }
                if (time9 == null) {
                    time9 = data.student[arr].time9;
                    if (time9 == null) {
                        time9 = "";
                    }
                }
                if (time10 == null) {
                    time10 = data.student[arr].time10;
                    if (time10 == null) {
                        time10 = "";
                    }
                }
                if (time11 == null) {
                    time11 = data.student[arr].time11;
                    if (time11 == null) {
                        time11 = "";
                    }
                }
                if (time12 == null) {
                    time12 = data.student[arr].time12;
                    if (time12 == null) {
                        time12 = "";
                    }
                }
                if (time13 == null) {
                    time13 = data.student[arr].time13;
                    if (time13 == null) {
                        time13 = "";
                    }
                }
            }

            for (var i = timet_s; i <= timet_e; i++) {
                switch (i) {
                    case 1: timet1 = subject_name + ' | ' + student_groups_name; break;
                    case 2: timet2 = subject_name + ' | ' + student_groups_name; break;
                    case 3: timet3 = subject_name + ' | ' + student_groups_name; break;
                    case 4: timet4 = subject_name + ' | ' + student_groups_name; break;
                    case 5: timet5 = subject_name + ' | ' + student_groups_name; break;
                    case 6: timet6 = subject_name + ' | ' + student_groups_name; break;
                    case 7: timet7 = subject_name + ' | ' + student_groups_name; break;
                    case 8: timet8 = subject_name + ' | ' + student_groups_name; break;
                    case 9: timet9 = subject_name + ' | ' + student_groups_name; break;
                    case 10: timet10 = subject_name + ' | ' + student_groups_name; break;
                    case 11: timet11 = subject_name + ' | ' + student_groups_name; break;
                    case 12: timet12 = subject_name + ' | ' + student_groups_name; break;
                    case 13: timet13 = subject_name + ' | ' + student_groups_name; break;
                }


                var arr = parseInt(day_id) - 1;
                if (timet1 == null) {
                    timet1 = data.student[arr].time1;
                    if (timet1 == null) {
                        timet1 = "";
                    }
                }
                if (timet2 == null) {
                    timet2 = data.student[arr].time2;
                    if (timet2 == null) {
                        timet2 = "";
                    }
                }
                if (timet3 == null) {
                    timet3 = data.student[arr].time3;
                    if (timet3 == null) {
                        timet3 = "";
                    }
                }
                if (timet4 == null) {
                    timet4 = data.student[arr].time4;
                    if (timet4 == null) {
                        timet4 = "";
                    }
                }
                if (timet5 == null) {
                    timet5 = data.student[arr].time5;
                    if (timet5 == null) {
                        timet5 = "";
                    }
                }
                if (timet6 == null) {
                    timet6 = data.student[arr].time6;
                    if (timet6 == null) {
                        timet6 = "";
                    }
                }
                if (timet7 == null) {
                    timet7 = data.student[arr].time7;
                    if (timet7 == null) {
                        timet7 = "";
                    }
                }
                if (timet8 == null) {
                    timet8 = data.student[arr].time8;
                    if (timet8 == null) {
                        timet8 = "";
                    }
                }
                if (timet9 == null) {
                    timet9 = data.student[arr].time9;
                    if (timet9 == null) {
                        timet9 = "";
                    }
                }
                if (timet10 == null) {
                    timet10 = data.student[arr].time10;
                    if (timet10 == null) {
                        timet10 = "";
                    }
                }
                if (timet11 == null) {
                    timet11 = data.student[arr].time11;
                    if (timet11 == null) {
                        timet11 = "";
                    }
                }
                if (timet12 == null) {
                    timet12 = data.student[arr].time12;
                    if (timet12 == null) {
                        timet12 = "";
                    }
                }
                if (timet13 == null) {
                    timet13 = data.student[arr].time13;
                    if (timet13 == null) {
                        timet13 = "";
                    }
                }
            }

            for (var i = timel_s; i <= timel_e; i++) {
                switch (i) {
                    case 1: timel1 = subject_name + ' | ' + student_groups_name; break;
                    case 2: timel2 = subject_name + ' | ' + student_groups_name; break;
                    case 3: timel3 = subject_name + ' | ' + student_groups_name; break;
                    case 4: timel4 = subject_name + ' | ' + student_groups_name; break;
                    case 5: timel5 = subject_name + ' | ' + student_groups_name; break;
                    case 6: timel6 = subject_name + ' | ' + student_groups_name; break;
                    case 7: timel7 = subject_name + ' | ' + student_groups_name; break;
                    case 8: timel8 = subject_name + ' | ' + student_groups_name; break;
                    case 9: timel9 = subject_name + ' | ' + student_groups_name; break;
                    case 10: timel10 = subject_name + ' | ' + student_groups_name; break;
                    case 11: timel11 = subject_name + ' | ' + student_groups_name; break;
                    case 12: timel12 = subject_name + ' | ' + student_groups_name; break;
                    case 13: timel13 = subject_name + ' | ' + student_groups_name; break;
                }

                var arr = parseInt(day_id) - 1;
                if (timel1 == null) {
                    timel1 = data.student[arr].time1;
                    if (timel1 == null) {
                        timel1 = "";
                    }
                }
                if (timel2 == null) {
                    timel2 = data.student[arr].time2;
                    if (timel2 == null) {
                        timel2 = "";
                    }
                }
                if (timel3 == null) {
                    timel3 = data.student[arr].time3;
                    if (timel3 == null) {
                        timel3 = "";
                    }
                }
                if (timel4 == null) {
                    timel4 = data.student[arr].time4;
                    if (timel4 == null) {
                        timel4 = "";
                    }
                }
                if (timel5 == null) {
                    timel5 = data.student[arr].time5;
                    if (timel5 == null) {
                        timel5 = "";
                    }
                }
                if (timel6 == null) {
                    timel6 = data.student[arr].time6;
                    if (timel6 == null) {
                        timel6 = "";
                    }
                }
                if (timel7 == null) {
                    timel7 = data.student[arr].time7;
                    if (timel7 == null) {
                        timel7 = "";
                    }
                }
                if (timel8 == null) {
                    timel8 = data.student[arr].time8;
                    if (timel8 == null) {
                        timel8 = "";
                    }
                }
                if (timel9 == null) {
                    timel9 = data.student[arr].time9;
                    if (timel9 == null) {
                        timel9 = "";
                    }
                }
                if (timel10 == null) {
                    timel10 = data.student[arr].time10;
                    if (timel10 == null) {
                        timel10 = "";
                    }
                }
                if (timel11 == null) {
                    timel11 = data.student[arr].time11;
                    if (timel11 == null) {
                        timel11 = "";
                    }
                }
                if (timel12 == null) {
                    timel12 = data.student[arr].time12;
                    if (timel12 == null) {
                        timel12 = "";
                    }
                }
                if (timel13 == null) {
                    timel13 = data.student[arr].time13;
                    if (timel13 == null) {
                        timel13 = "";
                    }
                }
            }
        }


        var day_name;
        var day = parseInt(day_id);
        switch (day) {
            case 1: day_name = 'SUN'; break;
            case 2: day_name = 'MON'; break;
            case 3: day_name = 'TUE'; break;
            case 4: day_name = 'WED'; break;
            case 5: day_name = 'THU'; break;
            case 6: day_name = 'FRI'; break;
            case 7: day_name = 'SAT'; break;
        }
        var room_t;
        var room_l;
        var time_t;
        var time_l;
        var teacher_t;
        var teacher_l;

        console.log("day_id", day_id, "sumTotal", sumTotal)
        if (sumTotal == 0) {
            if (timet_s > timet_e) {
                var SQL6 = `UPDATE view_timetable 
                SET room_t = '${room_id}', room_l = '${rooml_id}', 
                time_t = '', time_l = '${day_name + ' ' + timel_s + '-' + timel_e}', 
                teacher_t = '${teacher_id}', teacher_l = '${teacher_id}'
                WHERE subject_id = '${subject_id}' AND student_groups_id = '${student_groups_id}' AND term_id = '${term_id}' AND year_id = '${year_id}'`;
                await db.query(SQL6, [subject_id, student_groups_id, room_t, room_l, time_t, time_l, teacher_t, teacher_l, term_id, year_id], callback);
            }
            if (timel_s > timel_e) {
                var SQL5 = `UPDATE view_timetable 
                SET room_t = '${room_id}', room_l = '${rooml_id}', 
                time_t = '${day_name + ' ' + timet_s + '-' + timet_e}', time_l = '', 
                teacher_t = '${teacher_id}', teacher_l = '${teacher_id}'
                WHERE subject_id = '${subject_id}' AND student_groups_id = '${student_groups_id}' AND term_id = '${term_id}' AND year_id = '${year_id}'`;
                await db.query(SQL5, [subject_id, student_groups_id, room_t, room_l, time_t, time_l, teacher_t, teacher_l, term_id, year_id], callback);
            }
            if (timet_s < timet_e && timel_s < timel_e) {
                var SQL7 = `UPDATE view_timetable 
                SET room_t = '${room_id}', room_l = '${rooml_id}', 
                time_t = '${day_name + ' ' + timet_s + '-' + timet_e}', time_l = '${day_name + ' ' + timel_s + '-' + timel_e}', 
                teacher_t = '${teacher_id}', teacher_l = '${teacher_id}'
                WHERE subject_id = '${subject_id}' AND student_groups_id = '${student_groups_id}' AND term_id = '${term_id}' AND year_id = '${year_id}'`;
                await db.query(SQL7, [subject_id, student_groups_id, room_t, room_l, time_t, time_l, teacher_t, teacher_l, term_id, year_id], callback);
            }

            var SQL = `UPDATE teacher_7x13 SET time1 = '${time1}', time2 = '${time2}', time3 = '${time3}', time4 = '${time4}', time5 = '${time5}', time6 = '${time6}', time7 = '${time7}', time8 = '${time8}', time9 = '${time9}', time10 = '${time10}', time11 = '${time11}', time12 = '${time12}', time13 = '${time13}'
            WHERE teacher_id = '${teacher_id}' AND year_id = '${year_id}' AND term_id = '${term_id}' AND day_id = '${day_id}'`;
            await db.query(SQL, [time1, time2, time3, time4, time5, time6, time7, time8, time9, time10, time11, time12, time13, teacher_id, year_id, term_id, day_id]);

            var SQL1 = `UPDATE student_groups_7x13 SET time1 = '${time1}', time2 = '${time2}', time3 = '${time3}', time4 = '${time4}', time5 = '${time5}', time6 = '${time6}', time7 = '${time7}', time8 = '${time8}', time9 = '${time9}', time10 = '${time10}', time11 = '${time11}', time12 = '${time12}', time13 = '${time13}'
            WHERE student_groups_id = '${student_groups_id}' AND year_id = '${year_id}' AND term_id = '${term_id}' AND day_id = '${day_id}'`;
            await db.query(SQL1, [time1, time2, time3, time4, time5, time6, time7, time8, time9, time10, time11, time12, time13, student_groups_id, year_id, term_id, day_id]);

            if (room_id === rooml_id) {

                var SQL2 = `UPDATE room_7x13 SET time1 = '${time1}', time2 = '${time2}', time3 = '${time3}', time4 = '${time4}', time5 = '${time5}', time6 = '${time6}', time7 = '${time7}', time8 = '${time8}', time9 = '${time9}', time10 = '${time10}', time11 = '${time11}', time12 = '${time12}', time13 = '${time13}'
                WHERE room_id = '${room_id}' AND year_id = '${year_id}' AND term_id = '${term_id}' AND day_id = '${day_id}'`;
                await db.query(SQL2, [time1, time2, time3, time4, time5, time6, time7, time8, time9, time10, time11, time12, time13, room_id, year_id, term_id, day_id]);

            } else {

                var SQL3 = `UPDATE room_7x13 SET time1 = '${timet1}', time2 = '${timet2}', time3 = '${timet3}', time4 = '${timet4}', time5 = '${timet5}', time6 = '${timet6}', time7 = '${timet7}', time8 = '${timet8}', time9 = '${timet9}', time10 = '${timet10}', time11 = '${timet11}', time12 = '${timet12}', time13 = '${timet13}'
                WHERE room_id = '${room_id}' AND year_id = '${year_id}' AND term_id = '${term_id}' AND day_id = '${day_id}'`;
                await db.query(SQL3, [time1, time2, time3, time4, time5, time6, time7, time8, time9, time10, time11, time12, time13, room_id, year_id, term_id, day_id]);

                var SQL4 = `UPDATE room_7x13 SET time1 = '${timel1}', time2 = '${timel2}', time3 = '${timel3}', time4 = '${timel4}', time5 = '${timel5}', time6 = '${timel6}', time7 = '${timel7}', time8 = '${timel8}', time9 = '${timel9}', time10 = '${timel10}', time11 = '${timel11}', time12 = '${timel12}', time13 = '${timel13}'
                WHERE room_id = '${rooml_id}' AND year_id = '${year_id}' AND term_id = '${term_id}' AND day_id = '${day_id}'`;
                await db.query(SQL4, [time1, time2, time3, time4, time5, time6, time7, time8, time9, time10, time11, time12, time13, room_id, year_id, term_id, day_id]);
            }
            var SQL8 = `INSERT INTO check_dd_timetable(subject_id, student_groups_id, term_id, year_id) VALUES ('${subject_id}','${student_groups_id}','${term_id}','${year_id}')`
            await db.query(SQL8, [subject_id, student_groups_id, term_id, year_id]);
        }
        else {
            
            console.log("ไม่สามารถเพิ่มข้อมูลได้เนื่องจากมีข้อมูลทับกัน")
        }


    },

    // delete timetable
    deleteTimetable: async function (data, callback) {
        var term_id = data.term_id;
        var year_id = data.year_id;
        var day_id = data.day_id;
        var time1; var time2; var time3;
        var time4; var time5; var time6;
        var time7; var time8; var time9;
        var time10; var time11; var time12;
        var time13;
        var timet1; var timet2; var timet3;
        var timet4; var timet5; var timet6;
        var timet7; var timet8; var timet9;
        var timet10; var timet11; var timet12;
        var timet13;
        var timel1; var timel2; var timel3;
        var timel4; var timel5; var timel6;
        var timel7; var timel8; var timel9;
        var timel10; var timel11; var timel12;
        var timel13;
        var subject_unit = data.subject_unit;
        var subject_id = data.subject_id;
        var room_id = data.room_id;
        var rooml_id = data.rooml_id;
        var student_groups_id = data.student_groups_id;
        var teacher_id = data.teacher_id;

        var input = subject_unit;
        var output1 = input.substring(2, 3);
        var output2 = input.substring(4, 5);
        var a = parseInt(output1) // T
        var b = parseInt(output2) // L
        console.log(output1, output2)
        var time = data.time;
        var time = parseInt(data.time)
        var column = time;
        var timet_s = parseInt(column);
        var timet_e = parseInt(column + a - 1);
        var timel_s = parseInt(column + a);
        var timel_e = parseInt(column + a + b - 1);
        console.log("time_start", timet_s, "time_end", timel_e);
        console.log("time_t_start", timet_s, "time_t_end", timet_e);
        console.log("time_l_start", timel_s, "time_l_end", timel_e);
        for (var i = timet_s; i <= timel_e; i++) {
            switch (i) {
                case 1: time1 = ''; break;
                case 2: time2 = ''; break;
                case 3: time3 = ''; break;
                case 4: time4 = ''; break;
                case 5: time5 = ''; break;
                case 6: time6 = ''; break;
                case 7: time7 = ''; break;
                case 8: time8 = ''; break;
                case 9: time9 = ''; break;
                case 10: time10 = ''; break;
                case 11: time11 = ''; break;
                case 12: time12 = ''; break;
                case 13: time13 = ''; break;
            }


            var arr = parseInt(day_id) - 1;
            if (time1 == null) {
                time1 = data.student[arr].time1;
                if (time1 == null) {
                    time1 = "";
                }
            }
            if (time2 == null) {
                time2 = data.student[arr].time2;
                if (time2 == null) {
                    time2 = "";
                }
            }
            if (time3 == null) {
                time3 = data.student[arr].time3;
                if (time3 == null) {
                    time3 = "";
                }
            }
            if (time4 == null) {
                time4 = data.student[arr].time4;
                if (time4 == null) {
                    time4 = "";
                }
            }
            if (time5 == null) {
                time5 = data.student[arr].time5;
                if (time5 == null) {
                    time5 = "";
                }
            }
            if (time6 == null) {
                time6 = data.student[arr].time6;
                if (time6 == null) {
                    time6 = "";
                }
            }
            if (time7 == null) {
                time7 = data.student[arr].time7;
                if (time7 == null) {
                    time7 = "";
                }
            }
            if (time8 == null) {
                time8 = data.student[arr].time8;
                if (time8 == null) {
                    time8 = "";
                }
            }
            if (time9 == null) {
                time9 = data.student[arr].time9;
                if (time9 == null) {
                    time9 = "";
                }
            }
            if (time10 == null) {
                time10 = data.student[arr].time10;
                if (time10 == null) {
                    time10 = "";
                }
            }
            if (time11 == null) {
                time11 = data.student[arr].time11;
                if (time11 == null) {
                    time11 = "";
                }
            }
            if (time12 == null) {
                time12 = data.student[arr].time12;
                if (time12 == null) {
                    time12 = "";
                }
            }
            if (time13 == null) {
                time13 = data.student[arr].time13;
                if (time13 == null) {
                    time13 = "";
                }
            }
        }

        for (var i = timet_s; i <= timet_e; i++) {
            switch (i) {
                case 1: timet1 = ''; break;
                case 2: timet2 = ''; break;
                case 3: timet3 = ''; break;
                case 4: timet4 = ''; break;
                case 5: timet5 = ''; break;
                case 6: timet6 = ''; break;
                case 7: timet7 = ''; break;
                case 8: timet8 = ''; break;
                case 9: timet9 = ''; break;
                case 10: timet10 = ''; break;
                case 11: timet11 = ''; break;
                case 12: timet12 = ''; break;
                case 13: timet13 = ''; break;
            }


            var arr = parseInt(day_id) - 1;
            if (timet1 == null) {
                timet1 = data.room[arr].time1;
                if (timet1 == null) {
                    timet1 = "";
                }
            }
            if (timet2 == null) {
                timet2 = data.room[arr].time2;
                if (timet2 == null) {
                    timet2 = "";
                }
            }
            if (timet3 == null) {
                timet3 = data.room[arr].time3;
                if (timet3 == null) {
                    timet3 = "";
                }
            }
            if (timet4 == null) {
                timet4 = data.room[arr].time4;
                if (timet4 == null) {
                    timet4 = "";
                }
            }
            if (timet5 == null) {
                timet5 = data.room[arr].time5;
                if (timet5 == null) {
                    timet5 = "";
                }
            }
            if (timet6 == null) {
                timet6 = data.room[arr].time6;
                if (timet6 == null) {
                    timet6 = "";
                }
            }
            if (timet7 == null) {
                timet7 = data.room[arr].time7;
                if (timet7 == null) {
                    timet7 = "";
                }
            }
            if (timet8 == null) {
                timet8 = data.room[arr].time8;
                if (timet8 == null) {
                    timet8 = "";
                }
            }
            if (timet9 == null) {
                timet9 = data.room[arr].time9;
                if (timet9 == null) {
                    timet9 = "";
                }
            }
            if (timet10 == null) {
                timet10 = data.room[arr].time10;
                if (timet10 == null) {
                    timet10 = "";
                }
            }
            if (timet11 == null) {
                timet11 = data.room[arr].time11;
                if (timet11 == null) {
                    timet11 = "";
                }
            }
            if (timet12 == null) {
                timet12 = data.room[arr].time12;
                if (timet12 == null) {
                    timet12 = "";
                }
            }
            if (timet13 == null) {
                timet13 = data.room[arr].time13;
                if (timet13 == null) {
                    timet13 = "";
                }
            }
        }



        for (var i = timel_s; i <= timel_e; i++) {
            switch (i) {
                case 1: timel1 = ''; break;
                case 2: timel2 = ''; break;
                case 3: timel3 = ''; break;
                case 4: timel4 = ''; break;
                case 5: timel5 = ''; break;
                case 6: timel6 = ''; break;
                case 7: timel7 = ''; break;
                case 8: timel8 = ''; break;
                case 9: timel9 = ''; break;
                case 10: timel10 = ''; break;
                case 11: timel11 = ''; break;
                case 12: timel12 = ''; break;
                case 13: timel13 = ''; break;
            }

            var arr = parseInt(day_id) - 1;
            if (timel1 == null) {
                timel1 = data.rooml[arr].time1;
                if (timel1 == null) {
                    timel1 = "";
                }
            }
            if (timel2 == null) {
                timel2 = data.rooml[arr].time2;
                if (timel2 == null) {
                    timel2 = "";
                }
            }
            if (timel3 == null) {
                timel3 = data.rooml[arr].time3;
                if (timel3 == null) {
                    timel3 = "";
                }
            }
            if (timel4 == null) {
                timel4 = data.rooml[arr].time4;
                if (timel4 == null) {
                    timel4 = "";
                }
            }
            if (timel5 == null) {
                timel5 = data.rooml[arr].time5;
                if (timel5 == null) {
                    timel5 = "";
                }
            }
            if (timel6 == null) {
                timel6 = data.rooml[arr].time6;
                if (timel6 == null) {
                    timel6 = "";
                }
            }
            if (timel7 == null) {
                timel7 = data.rooml[arr].time7;
                if (timel7 == null) {
                    timel7 = "";
                }
            }
            if (timel8 == null) {
                timel8 = data.rooml[arr].time8;
                if (timel8 == null) {
                    timel8 = "";
                }
            }
            if (timel9 == null) {
                timel9 = data.rooml[arr].time9;
                if (timel9 == null) {
                    timel9 = "";
                }
            }
            if (timel10 == null) {
                timel10 = data.rooml[arr].time10;
                if (timel10 == null) {
                    timel10 = "";
                }
            }
            if (timel11 == null) {
                timel11 = data.rooml[arr].time11;
                if (timel11 == null) {
                    timel11 = "";
                }
            }
            if (timel12 == null) {
                timel12 = data.rooml[arr].time12;
                if (timel12 == null) {
                    timel12 = "";
                }
            }
            if (timel13 == null) {
                timel13 = data.rooml[arr].time13;
                if (timel13 == null) {
                    timel13 = "";
                }
            }
        }

        var room_t;
        var room_l;
        var time_t;
        var time_l;
        var teacher_t;
        var teacher_l;

        if (timet_s > timet_e) {
            var SQL6 = `UPDATE view_timetable 
            SET room_t = '', room_l = '', 
            time_t = '', time_l = '', 
            teacher_t = '', teacher_l = ''
            WHERE subject_id = '${subject_id}' AND student_groups_id = '${student_groups_id}' AND term_id = '${term_id}' AND year_id = '${year_id}'`;
            await db.query(SQL6, [subject_id, student_groups_id, room_t, room_l, time_t, time_l, teacher_t, teacher_l, term_id, year_id], callback);
        }
        if (timel_s > timel_e) {
            var SQL5 = `UPDATE view_timetable 
            SET room_t = '', room_l = '', 
            time_t = '', time_l = '', 
            teacher_t = '', teacher_l = ''
            WHERE subject_id = '${subject_id}' AND student_groups_id = '${student_groups_id}' AND term_id = '${term_id}' AND year_id = '${year_id}'`;
            await db.query(SQL5, [subject_id, student_groups_id, room_t, room_l, time_t, time_l, teacher_t, teacher_l, term_id, year_id], callback);
        }
        if (timet_s < timet_e && timel_s < timel_e) {
            var SQL7 = `UPDATE view_timetable 
            SET room_t = '', room_l = '', 
            time_t = '', time_l = '', 
            teacher_t = '', teacher_l = ''
            WHERE subject_id = '${subject_id}' AND student_groups_id = '${student_groups_id}' AND term_id = '${term_id}' AND year_id = '${year_id}'`;
            await db.query(SQL7, [subject_id, student_groups_id, room_t, room_l, time_t, time_l, teacher_t, teacher_l, term_id, year_id], callback);
        }

        var SQL = `UPDATE teacher_7x13 SET time1 = '${time1}', time2 = '${time2}', time3 = '${time3}', time4 = '${time4}', time5 = '${time5}', time6 = '${time6}', time7 = '${time7}', time8 = '${time8}', time9 = '${time9}', time10 = '${time10}', time11 = '${time11}', time12 = '${time12}', time13 = '${time13}'
            WHERE teacher_id = '${teacher_id}' AND year_id = '${year_id}' AND term_id = '${term_id}' AND day_id = '${day_id}'`;
        await db.query(SQL, [time1, time2, time3, time4, time5, time6, time7, time8, time9, time10, time11, time12, time13, teacher_id, year_id, term_id, day_id]);

        var SQL1 = `UPDATE student_groups_7x13 SET time1 = '${time1}', time2 = '${time2}', time3 = '${time3}', time4 = '${time4}', time5 = '${time5}', time6 = '${time6}', time7 = '${time7}', time8 = '${time8}', time9 = '${time9}', time10 = '${time10}', time11 = '${time11}', time12 = '${time12}', time13 = '${time13}'
            WHERE student_groups_id = '${student_groups_id}' AND year_id = '${year_id}' AND term_id = '${term_id}' AND day_id = '${day_id}'`;
        await db.query(SQL1, [time1, time2, time3, time4, time5, time6, time7, time8, time9, time10, time11, time12, time13, student_groups_id, year_id, term_id, day_id]);

        if (room_id === rooml_id) {

            var SQL2 = `UPDATE room_7x13 SET time1 = '${time1}', time2 = '${time2}', time3 = '${time3}', time4 = '${time4}', time5 = '${time5}', time6 = '${time6}', time7 = '${time7}', time8 = '${time8}', time9 = '${time9}', time10 = '${time10}', time11 = '${time11}', time12 = '${time12}', time13 = '${time13}'
            WHERE room_id = '${room_id}' AND year_id = '${year_id}' AND term_id = '${term_id}' AND day_id = '${day_id}'`;
            await db.query(SQL2, [time1, time2, time3, time4, time5, time6, time7, time8, time9, time10, time11, time12, time13, room_id, year_id, term_id, day_id]);

        } else {

            var SQL3 = `UPDATE room_7x13 SET time1 = '${timet1}', time2 = '${timet2}', time3 = '${timet3}', time4 = '${timet4}', time5 = '${timet5}', time6 = '${timet6}', time7 = '${timet7}', time8 = '${timet8}', time9 = '${timet9}', time10 = '${timet10}', time11 = '${timet11}', time12 = '${timet12}', time13 = '${timet13}'
            WHERE room_id = '${room_id}' AND year_id = '${year_id}' AND term_id = '${term_id}' AND day_id = '${day_id}'`;
            await db.query(SQL3, [time1, time2, time3, time4, time5, time6, time7, time8, time9, time10, time11, time12, time13, room_id, year_id, term_id, day_id]);

            var SQL4 = `UPDATE room_7x13 SET time1 = '${timel1}', time2 = '${timel2}', time3 = '${timel3}', time4 = '${timel4}', time5 = '${timel5}', time6 = '${timel6}', time7 = '${timel7}', time8 = '${timel8}', time9 = '${timel9}', time10 = '${timel10}', time11 = '${timel11}', time12 = '${timel12}', time13 = '${timel13}'
            WHERE room_id = '${rooml_id}' AND year_id = '${year_id}' AND term_id = '${term_id}' AND day_id = '${day_id}'`;
            await db.query(SQL4, [time1, time2, time3, time4, time5, time6, time7, time8, time9, time10, time11, time12, time13, room_id, year_id, term_id, day_id]);
        }
        var SQL8 = `DELETE FROM check_dd_timetable WHERE subject_id = ? AND student_groups_id = ? AND term_id = ? AND year_id = ?`
        await db.query(SQL8, [subject_id, student_groups_id, term_id, year_id]);
    },

}; module.exports = Update7x13;