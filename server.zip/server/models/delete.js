var db = require('../connectdb'); //reference of connectdb.js
var Delete = {

    //delete student
    deleteStudent: function (data, callback) {
        var selectSQL = 'DELETE FROM student WHERE student_id=?';
        var student_id = data
        return db.query(selectSQL, [student_id], callback);
    },

    //delete student groups
    deleteStudentGroups: function (data, callback) {
        var selectSQL = 'DELETE FROM student_groups WHERE student_groups_id=?';
        var student_groups_id = data
        return db.query(selectSQL, [student_groups_id], callback);
    },

    //delete teacher
    deleteTeacher: function (data, callback) {
        var selectSQL = 'DELETE FROM teacher WHERE teacher_id=?';
        var teacher_id = data
        return db.query(selectSQL, [teacher_id], callback);
    },

    //delete subject
    deleteSubject: function (data, callback) {
        var selectSQL = 'DELETE FROM subject WHERE subject_id=?';
        var subject_id = data
        return db.query(selectSQL, [subject_id], callback);
    },

    //delete room
    deleteRoom: function (data, callback) {
        var selectSQL = 'DELETE FROM room WHERE room_id=?';
        var room_id = data
        return db.query(selectSQL, [room_id], callback);
    },

    //delete RM21
    deleteRM21: async function (subject_id, student_groups_id, term_id, year_id, callback) {
        var selectSQL = `DELETE FROM rm21 WHERE subject_id = '${subject_id}' AND student_groups_id = '${student_groups_id}' AND term_id = '${term_id}' AND year_id = '${year_id}'`;
        var SQL = `DELETE FROM view_timetable WHERE subject_id = '${subject_id}' AND student_groups_id = '${student_groups_id}' AND term_id = '${term_id}' AND year_id = '${year_id}'`;
        await db.query(selectSQL, [subject_id, student_groups_id, term_id, year_id], callback);
        await db.query(SQL, [subject_id, student_groups_id, term_id, year_id]);
    },

    //delete subject teacher
    deleteSubjectTeacher: function (data, callback) {
        var selectSQL = `DELETE FROM subject_teacher WHERE subject_teacher_id = ?;`;
        var subject_teacher_id = data;
        return db.query(selectSQL, [subject_teacher_id], callback);
    },

}; module.exports = Delete;