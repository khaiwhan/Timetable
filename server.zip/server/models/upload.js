var db = require('../connectdb'); //reference of connectdb.js
var Upload = {

    //upload course
    uploadCourse: async function (data, course_id, callback) {
        var subject_id = data.subject_id;
        var subject_name = data.subject_name;
        var subject_unit = data.subject_unit;
        var required_subject = data.required_subject;
        var selectSQL = `INSERT INTO subject ( subject_id, subject_name, subject_unit, required_subject )
        VALUES ('${subject_id}','${subject_name}','${subject_unit}','${required_subject}');`;
        var SQL = `INSERT INTO course_subject ( course_id, subject_id) VALUES ('${course_id}','${subject_id}');`;
        await db.query(selectSQL, callback);
        await db.query(SQL, callback);
    },
}; module.exports = Upload;