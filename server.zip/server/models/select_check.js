var db = require('../connectdb'); //reference of connectdb.js
var SelectCheck = {

    //select add RM21 check
    selectRM21_C: function (data, callback) {
        var selectSQL = `SELECT
        subject_id, student_groups_id
        FROM rm21
        WHERE subject_id = ? AND student_groups_id = ?;`
        return db.query(selectSQL, [data.subject_id, data.student_groups_id], callback);
    },

    //select add subject teacher check
    selectSubjectTeacher_C: function (data, callback) {
        var selectSQL = `SELECT
        subject_id, teacher_t, teacher_l1, teacher_l2, teacher_l3, teacher_l4
        FROM subject_teacher
        WHERE subject_id = ? AND teacher_t = ? AND teacher_l1 = ? AND teacher_l2 = ? AND teacher_l3 = ? AND teacher_l4 = ?;`
        return db.query(selectSQL, [data.subject_id, data.teacher_t, data.teacher_l1, data.teacher_l2, data.teacher_l3, data.teacher_l4], callback);
    },

    //select add room check
    selectRoom_C: function (data, callback) {
        var selectSQL = `SELECT
        room_id
        FROM room
        WHERE room_id = ?;`
        return db.query(selectSQL, [data.room_id], callback);
    },

    //select add table 7x13 room check
    selectRoom7x13_C: function (data, callback) {
        var selectSQL = `SELECT
        room_id, year_id, term_id
        FROM room_7x13
        WHERE room_id = ? AND year_id = ? AND term_id = ?`;
        return db.query(selectSQL, [data.room_id, data.year_id, data.term_id], callback);
    },

    //select add table 7x13 student groups check
    selectStudentGroups7x13_C: function (data, callback) {
        var selectSQL = `SELECT
        student_groups_id, year_id, term_id
        FROM student_groups_7x13
        WHERE student_groups_id = ? AND year_id = ? AND term_id = ?`;
        return db.query(selectSQL, [data.student_groups_id, data.year_id, data.term_id], callback);
    },

    //select add table 7x13 teacher check
    selectTeacher7x13_C: function (data, callback) {
        var selectSQL = `SELECT teacher_id, year_id, term_id
        FROM teacher_7x13
        WHERE teacher_id = ? AND year_id = ? AND term_id = ?`;
        return db.query(selectSQL, [data.teacher_id, data.year_id, data.term_id], callback);
    },

    //select add student group check
    selectGroups_C: function (data, callback) {
        var selectSQL = `SELECT student_groups_name
        FROM student_groups
        WHERE student_groups_name = ?`;
        return db.query(selectSQL, [data.student_groups_name], callback);
    },


}; module.exports = SelectCheck;