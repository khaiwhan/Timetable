var db = require('../connectdb'); //reference of connectdb.js
var Select = {

    //select groups drop down
    selectGroups: function (data, callback) {
        var selectSQL = `SELECT * FROM student_groups 
        order by student_groups_name`;
        return db.query(selectSQL, callback);
    },

    //select course drop down
    selectCourse: function (data, callback) {
        var selectSQL = `SELECT * FROM course 
        order by course_name`;
        return db.query(selectSQL, callback);
    },

    //select term drop down
    selectTerm: function (data, callback) {
        var selectSQL = `SELECT * FROM term 
        order by term_name`;
        return db.query(selectSQL, callback);
    },

    //select day drop down
    selectDay: function (data, callback) {
        var selectSQL = `SELECT * FROM day 
        order by day_id`;
        return db.query(selectSQL, callback);
    },

    //select time drop down
    selectTime: function (data, callback) {
        var selectSQL = `SELECT * FROM time 
        order by time_id`;
        return db.query(selectSQL, callback);
    },

    //select year drop down
    selectYear: function (data, callback) {
        var input = data;
        var output = input.substring(0, 2);
        if (output === '58') {
            var selectSQL = `SELECT * FROM year;`
            return db.query(selectSQL, callback);
        }
        else if (output === '59') {
            var selectSQL = `SELECT * FROM year
            WHERE NOT year_id = 1;`
            return db.query(selectSQL, callback);
        }
        else if (output === '60') {
            var selectSQL = `SELECT * FROM year
            WHERE NOT year_id = 1 AND NOT year_id = 2;`
            return db.query(selectSQL, callback);
        }
        else if (output === '61') {
            var selectSQL = `SELECT * FROM year
            WHERE NOT year_id = 1 AND NOT year_id = 2 AND NOT year_id = 3;`
            return db.query(selectSQL, callback);
        }
        else if (output === '62') {
            var selectSQL = `SELECT * FROM year
            WHERE NOT year_id = 1 AND NOT year_id = 2 AND NOT year_id = 3 AND NOT year_id = 4;`
            return db.query(selectSQL, callback);
        }
        else if (output === '63') {
            var selectSQL = `SELECT * FROM year
            WHERE NOT year_id = 1 AND NOT year_id = 2 AND NOT year_id = 3 AND NOT year_id = 4 
            AND NOT year_id = 5;`
            return db.query(selectSQL, callback);
        }
        else if (output === '64') {
            var selectSQL = `SELECT * FROM year
            WHERE NOT year_id = 1 AND NOT year_id = 2 AND NOT year_id = 3 AND NOT year_id = 4 
            AND NOT year_id = 5 AND NOT year_id = 6;`
            return db.query(selectSQL, callback);
        }
        else if (output === '65') {
            var selectSQL = `SELECT * FROM year
            WHERE NOT year_id = 1 AND NOT year_id = 2 AND NOT year_id = 3 AND NOT year_id = 4 
            AND NOT year_id = 5 AND NOT year_id = 6 AND NOT year_id = 7;`
            return db.query(selectSQL, callback);
        }
        else if (output === '66') {
            var selectSQL = `SELECT * FROM year
            WHERE NOT year_id = 1 AND NOT year_id = 2 AND NOT year_id = 3 AND NOT year_id = 4 
            AND NOT year_id = 5 AND NOT year_id = 6 AND NOT year_id = 7 AND NOT year_id = 8;`
            return db.query(selectSQL, callback);
        }
        else if (output === '67') {
            var selectSQL = `SELECT * FROM year
            WHERE NOT year_id = 1 AND NOT year_id = 2 AND NOT year_id = 3 AND NOT year_id = 4 
            AND NOT year_id = 5 AND NOT year_id = 6 AND NOT year_id = 7 AND NOT year_id = 8 
            AND NOT year_id = 9;`
            return db.query(selectSQL, callback);
        }
        else if (output === '68') {
            var selectSQL = `SELECT * FROM year
            WHERE NOT year_id = 1 AND NOT year_id = 2 AND NOT year_id = 3 AND NOT year_id = 4 
            AND NOT year_id = 5 AND NOT year_id = 6 AND NOT year_id = 7 AND NOT year_id = 8
            AND NOT year_id = 9 AND NOT year_id = 10;`
            return db.query(selectSQL, callback);
        }
        else if (output === '69') {
            var selectSQL = `SELECT * FROM year
            WHERE NOT year_id = 1 AND NOT year_id = 2 AND NOT year_id = 3 AND NOT year_id = 4 
            AND NOT year_id = 5 AND NOT year_id = 6 AND NOT year_id = 7 AND NOT year_id = 8
            AND NOT year_id = 9 AND NOT year_id = 10 AND NOT year_id = 11;`
            return db.query(selectSQL, callback);
        }
        else if (output === '70') {
            var selectSQL = `SELECT * FROM year
            WHERE NOT year_id = 1 AND NOT year_id = 2 AND NOT year_id = 3 AND NOT year_id = 4 
            AND NOT year_id = 5 AND NOT year_id = 6 AND NOT year_id = 7 AND NOT year_id = 8
            AND NOT year_id = 9 AND NOT year_id = 10 AND NOT year_id = 11 AND NOT year_id = 12;`
            return db.query(selectSQL, callback);
        }
        else if (output === '71') {
            var selectSQL = `SELECT * FROM year
            WHERE NOT year_id = 1 AND NOT year_id = 2 AND NOT year_id = 3 AND NOT year_id = 4 
            AND NOT year_id = 5 AND NOT year_id = 6 AND NOT year_id = 7 AND NOT year_id = 8
            AND NOT year_id = 9 AND NOT year_id = 10 AND NOT year_id = 11 AND NOT year_id = 12
            AND NOT year_id = 13;`
            return db.query(selectSQL, callback);
        }
        else if (output === '72') {
            var selectSQL = `SELECT * FROM year
            WHERE NOT year_id = 1 AND NOT year_id = 2 AND NOT year_id = 3 AND NOT year_id = 4 
            AND NOT year_id = 5 AND NOT year_id = 6 AND NOT year_id = 7 AND NOT year_id = 8
            AND NOT year_id = 9 AND NOT year_id = 10 AND NOT year_id = 11 AND NOT year_id = 12
            AND NOT year_id = 13 AND NOT year_id = 14;`
            return db.query(selectSQL, callback);
        }
        else {
            var selectSQL = `SELECT * FROM year;`
            return db.query(selectSQL, callback);
        }
    },


    //select student
    selectStudent: function (data, callback) {
        var selectSQL = `SELECT student.student_id, student.student_password,
        student.student_name, student_groups.student_groups_name 
        FROM student 
        LEFT JOIN student_groups ON student.student_groups_id = student_groups.student_groups_id order by student_id`;
        return db.query(selectSQL, callback);
    },

    //select teacher
    selectTeacher: function (data, callback) {
        var selectSQL = `SELECT * FROM teacher WHERE NOT teacher_id = '' AND NOT teacher_id = '-' ORDER BY teacher_name`;
        return db.query(selectSQL, callback);
    },

    //select subject
    selectSubject: function (data, callback) {
        var selectSQL = `SELECT * FROM subject order by subject_name`;
        return db.query(selectSQL, callback);
    },

    //select room
    selectRoom: function (data, callback) {
        var selectSQL = `SELECT * FROM room order by room_id`;
        return db.query(selectSQL, callback);
    },

    //select groups for show after choose group
    selectGroupsOfShow: function (data, callback) {
        var selectSQL = `SELECT
        subject.subject_id,
        subject.subject_name,
        subject.subject_unit,
        subject.required_subject
        FROM
        subject
        LEFT JOIN course_subject ON course_subject.subject_id = subject.subject_id
        LEFT JOIN course ON course_subject.course_id = course.course_id
        LEFT JOIN course_student_groups ON course_student_groups.course_id = course.course_id
        LEFT JOIN student_groups ON course_student_groups.student_groups_id = student_groups.student_groups_id
        WHERE
        student_groups.student_groups_name = ?`;
        var student_groups_name = data;
        console.log(data)
        return db.query(selectSQL, [student_groups_name], callback);
    },

    //select subject by course
    selectSubjectCourse: function (data, callback) {
        var selectSQL = `SELECT
        course.course_name,
        subject.subject_id,
        subject.subject_name,
        subject.subject_unit,
        subject.required_subject
        FROM
        course
        LEFT JOIN course_subject ON course_subject.course_id = course.course_id
        LEFT JOIN subject ON course_subject.subject_id = subject.subject_id
        WHERE course.course_id = ?`;
        var student_groups_id = data;
        console.log(data)
        return db.query(selectSQL, [student_groups_id], callback);
    },

    //select RM21
    selectRM21: function (data, callback) {
        var selectSQL = `SELECT
        subject.subject_id,
        subject.subject_name,
        subject.subject_unit,
        term.term_name,
        year.year_name,
        student_groups.student_groups_id,
        student_groups.student_groups_name
        FROM
        rm21
        LEFT JOIN subject ON rm21.subject_id = subject.subject_id
        LEFT JOIN term ON rm21.term_id = term.term_id
        LEFT JOIN year ON rm21.year_id = year.year_id
        LEFT JOIN student_groups ON rm21.student_groups_id = student_groups.student_groups_id
        WHERE rm21.student_groups_id = ?
        ORDER BY term.term_name, subject.subject_id;`
        var student_groups_id = data;
        return db.query(selectSQL, [student_groups_id], callback);
    },

    //select subject teacher
    selectSubjectTeacher: function (data, callback) {
        var selectSQL = `SELECT subject.subject_name,
        subject_teacher.subject_teacher_id,
        subject_teacher.teacher_t,
        subject_teacher.teacher_l1,
        subject_teacher.teacher_l2,
        subject_teacher.teacher_l3,
        subject_teacher.teacher_l4
        FROM subject_teacher
        LEFT JOIN subject ON subject_teacher.subject_id = subject.subject_id`;
        return db.query(selectSQL, callback);
    },

    //select teacher 7x13
    selectTeacher7x13: function (teacher_id, year_id, term_id, callback) {
        var selectSQL = `SELECT day.day_name,
        teacher_7x13.time1, teacher_7x13.time2,
        teacher_7x13.time3, teacher_7x13.time4,
        teacher_7x13.time5, teacher_7x13.time6,
        teacher_7x13.time7, teacher_7x13.time8,
        teacher_7x13.time9, teacher_7x13.time10,
        teacher_7x13.time11, teacher_7x13.time12,
        teacher_7x13.time13
        FROM teacher_7x13
        LEFT JOIN day ON teacher_7x13.day_id = day.day_id
        WHERE teacher_7x13.teacher_id = ? AND teacher_7x13.year_id = ? AND teacher_7x13.term_id = ?`;
        return db.query(selectSQL, [teacher_id, year_id, term_id], callback);
    },

    //select student groups 7x13
    selectStudentGroups7x13: function (student_groups_id, year_id, term_id, callback) {
        var selectSQL = `SELECT day.day_name,
        student_groups_7x13.time1, student_groups_7x13.time2,
        student_groups_7x13.time3, student_groups_7x13.time4,
        student_groups_7x13.time5, student_groups_7x13.time6,
        student_groups_7x13.time7, student_groups_7x13.time8,
        student_groups_7x13.time9, student_groups_7x13.time10,
        student_groups_7x13.time11, student_groups_7x13.time12,
        student_groups_7x13.time13
        FROM student_groups_7x13
        LEFT JOIN day ON student_groups_7x13.day_id = day.day_id
        WHERE student_groups_7x13.student_groups_id = ? AND student_groups_7x13.year_id = ? AND student_groups_7x13.term_id = ?`;
        return db.query(selectSQL, [student_groups_id, year_id, term_id], callback);
    },

    //select room 7x13
    selectRoom7x13: function (room_id, year_id, term_id, callback) {
        var selectSQL = `SELECT room_7x13.time1,
        room_7x13.time2, room_7x13.time3,
        room_7x13.time4, room_7x13.time5,
        room_7x13.time6, room_7x13.time7,
        room_7x13.time8, room_7x13.time9,
        room_7x13.time10, room_7x13.time11,
        room_7x13.time12, room_7x13.time13,
        day.day_name
        FROM room_7x13
        LEFT JOIN day ON room_7x13.day_id = day.day_id
        WHERE room_7x13.room_id = ? AND room_7x13.year_id = ? AND room_7x13.term_id = ?`;
        return db.query(selectSQL, [room_id, year_id, term_id], callback);
    },

    //select student_groups_id >>> year_id
    yearByGroups: function (data, callback) {
        var selectSQL = `SELECT rm21.student_groups_id,
        year.year_id, year.year_name
        FROM rm21
        LEFT JOIN year ON rm21.year_id = year.year_id
        WHERE student_groups_id = ?
        GROUP BY year.year_id`;
        var student_groups_id = data
        return db.query(selectSQL, [student_groups_id], callback);
    },

    //select year_id >>> term_id
    termByYear: function (data, callback) {
        var selectSQL = `SELECT rm21.year_id,
        term.term_id,term.term_name
        FROM rm21
        LEFT JOIN term ON rm21.term_id = term.term_id
        WHERE rm21.year_id = ?
        GROUP BY term_id`
        var year_id = data
        return db.query(selectSQL, [year_id], callback);
    },

    //select term_id >>> subject_id ### ADD ###
    subjectByTerm: function (term_id, year_id, student_groups_id, callback) {
        var selectSQL = `SELECT
        rm21.student_groups_id,
        rm21.subject_id,
        rm21.term_id,
        rm21.year_id,
        subject.subject_name,
        subject.subject_unit 
        FROM rm21
        LEFT JOIN SUBJECT ON rm21.subject_id = SUBJECT.subject_id 
        WHERE
        rm21.subject_id NOT IN ( SELECT subject_id FROM check_dd_timetable ) 
        AND rm21.term_id = '${term_id}' AND rm21.year_id = '${year_id}' AND rm21.student_groups_id = '${student_groups_id}'`
        return db.query(selectSQL, [term_id, year_id, student_groups_id], callback);
    },

    //select term_id >>> subject_id ### DELETE ###
    subjectByTermD: function (term_id, year_id, student_groups_id, callback) {
        var selectSQL = `SELECT
        check_dd_timetable.subject_id,
        subject.subject_name,
        subject.subject_unit,
        check_dd_timetable.student_groups_id,
        check_dd_timetable.term_id,
        check_dd_timetable.year_id
        FROM
        check_dd_timetable
        LEFT JOIN subject ON check_dd_timetable.subject_id = subject.subject_id
        WHERE check_dd_timetable.term_id = '${term_id}' AND check_dd_timetable.year_id = '${year_id}' AND check_dd_timetable.student_groups_id = '${student_groups_id}'`
        return db.query(selectSQL, [term_id, year_id, student_groups_id], callback);
    },

    //select subject_id >>> teacher_id
    teacherBySubject: function (data, callback) {
        var selectSQL = `SELECT
        subject_teacher.subject_id,
        subject_teacher.teacher_t
        FROM
        subject_teacher
        WHERE subject_teacher.subject_id = ?`
        var subject_id = data
        return db.query(selectSQL, [subject_id], callback);
    },

    //select View Timetable
    viewTimetable: function (year_id, term_id, callback) {
        var selectSQL = `SELECT
        subject.subject_id,
        subject.subject_name,
        subject.subject_unit,
        student_groups.student_groups_name,
        view_timetable.room_t,
        view_timetable.room_l,
        view_timetable.time_t,
        view_timetable.time_l,
        view_timetable.teacher_t,
        view_timetable.teacher_l
        FROM
        view_timetable
        LEFT JOIN subject ON view_timetable.subject_id = subject.subject_id
        LEFT JOIN student_groups ON view_timetable.student_groups_id = student_groups.student_groups_id
        WHERE view_timetable.year_id = ? AND view_timetable.term_id = ?
        ORDER BY subject.subject_name`
        return db.query(selectSQL, [year_id, term_id], callback);
    },

    //select display 0 , 1
    selectDisplay: function (data, callback) {
        var selectSQL = `SELECT * FROM display_timetable ORDER BY day_id`
        return db.query(selectSQL, callback);
    },

}; module.exports = Select;