var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var cors=require('cors');
var logger = require('morgan');


var indexRouter = require('./routes/index');
//login
var loginAdmin = require('./routes/login/loginAdmin');
var loginStudent = require('./routes/login/loginStudent');
var loginTeacher = require('./routes/login/loginTeacher');
//register
var registerStudent = require('./routes/register/registerStudent');
var registerTeacher = require('./routes/register/registerTeacher');
//add
var addStudentGroups = require('./routes/add/addStudentGroups');
var addRoom = require('./routes/add/addRoom');
var addSubject = require('./routes/add/addSubject');
var addRM21 = require('./routes/add/addRM21');
var addSubjectTeacher = require('./routes/add/addSubjectTeacher');
var addTeacher7x13 = require('./routes/add/addTeacher7x13');
var addStudentGroups7x13 = require('./routes/add/addStudentGroups7x13');
var addRoom7x13 = require('./routes/add/addRoom7x13');
//select
var selectGroups = require('./routes/select/selectGroups');
var selectStudent = require('./routes/select/selectStudent');
var selectTeacher = require('./routes/select/selectTeacher');
var selectSubject = require('./routes/select/selectSubject');
var selectRoom = require('./routes/select/selectRoom');
var selectCourse = require('./routes/select/selectCourse');
var selectGroupsOfShow = require('./routes/select/selectGroupsOfShow');
var selectTerm = require('./routes/select/selectTerm');
var selectYear = require('./routes/select/selectYear');
var selectSubjectCourse = require('./routes/select/selectSubjectCourse');
var selectRM21 = require('./routes/select/selectRM21');
var selectSubjectTeacher = require('./routes/select/selectSubjectTeacher');
var selectDay = require('./routes/select/selectDay');
var selectTime = require('./routes/select/selectTime');
var selectTeacher7x13 = require('./routes/select/selectTeacher7x13');
var selectRoom7x13 = require('./routes/select/selectRoom7x13');
var selectStudentGroups7x13 = require('./routes/select/selectStudentGroups7x13');
var viewTimetable = require('./routes/select/viewTimetable');
var selectDisplay = require('./routes/select/selectDisplay');
//delete
var deleteStudent = require('./routes/delete/deleteStudent');
var deleteStudentGroups = require('./routes/delete/deleteStudentGroups');
var deleteTeacher = require('./routes/delete/deleteTeacher');
var deleteSubject = require('./routes/delete/deleteSubject');
var deleteRoom = require('./routes/delete/deleteRoom');
var deleteRM21 = require('./routes/delete/deleteRM21');
var deleteSubjectTeacher = require('./routes/delete/deleteSubjectTeacher');
//update
var updateStudent = require('./routes/update/updateStudent');
var updateTeacher = require('./routes/update/updateTeacher');
var updateSubject = require('./routes/update/updateSubject');
var updateRoom = require('./routes/update/updateRoom');
var updateTeacher7x13 = require('./routes/update/updateTeacher7x13');
var updateStudentGroups7x13 = require('./routes/update/updateStudentGroups7x13');
var updateRoom7x13 = require('./routes/update/updateRoom7x13');
//7x13
var selectTimetable = require('./routes/7x13/selectTimetable');
var selectTimetableR = require('./routes/7x13/selectTimetableR');
var selectTimetableRR = require('./routes/7x13/selectTimetableRR');
var selectTimetableRRT = require('./routes/7x13/selectTimetableRRT');
var updateTimetable = require('./routes/7x13/updateTimetable');
var deleteTimetable = require('./routes/7x13/deleteTimetable');
//upload
var uploadCourse = require('./routes/upload/uploadCourse');
//manage timetable
var yearByGroups = require('./routes/manageTimetable/yearByGroups');
var termByYear = require('./routes/manageTimetable/termByYear');
var subjectByTerm = require('./routes/manageTimetable/subjectByTerm');
var subjectByTermD = require('./routes/manageTimetable/subjectByTermD');
var teacherBySubject = require('./routes/manageTimetable/teacherBySubject');



var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(cors());
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use('/', indexRouter);
//login
app.use('/loginAdmin',loginAdmin);
app.use('/loginStudent',loginStudent);
app.use('/loginTeacher',loginTeacher);
//register
app.use('/registerStudent',registerStudent);
app.use('/registerTeacher',registerTeacher);
//add
app.use('/addStudentGroups',addStudentGroups);
app.use('/addRoom',addRoom);
app.use('/addSubject',addSubject);
app.use('/addRM21',addRM21);
app.use('/addSubjectTeacher',addSubjectTeacher);
app.use('/addTeacher7x13',addTeacher7x13);
app.use('/addStudentGroups7x13',addStudentGroups7x13);
app.use('/addRoom7x13',addRoom7x13);
//select
app.use('/selectGroups',selectGroups);
app.use('/selectStudent',selectStudent);
app.use('/selectTeacher',selectTeacher);
app.use('/selectSubject',selectSubject);
app.use('/selectRoom',selectRoom);
app.use('/selectCourse',selectCourse);
app.use('/selectGroupsOfShow',selectGroupsOfShow);
app.use('/selectTerm',selectTerm);
app.use('/selectYear',selectYear);
app.use('/selectSubjectCourse',selectSubjectCourse);
app.use('/selectRM21',selectRM21);
app.use('/selectSubjectTeacher',selectSubjectTeacher);
app.use('/selectDay',selectDay);
app.use('/selectTime',selectTime);
app.use('/selectTeacher7x13',selectTeacher7x13);
app.use('/selectRoom7x13',selectRoom7x13);
app.use('/selectStudentGroups7x13',selectStudentGroups7x13);
app.use('/viewTimetable',viewTimetable);
app.use('/selectDisplay',selectDisplay);
//delete
app.use('/deleteStudent',deleteStudent);
app.use('/deleteStudentGroups',deleteStudentGroups);
app.use('/deleteTeacher',deleteTeacher);
app.use('/deleteSubject',deleteSubject);
app.use('/deleteRoom',deleteRoom);
app.use('/deleteRM21',deleteRM21);
app.use('/deleteSubjectTeacher',deleteSubjectTeacher);
//update
app.use('/updateStudent',updateStudent);
app.use('/updateTeacher',updateTeacher);
app.use('/updateSubject',updateSubject);
app.use('/updateRoom',updateRoom);
app.use('/updateTeacher7x13',updateTeacher7x13);
app.use('/updateStudentGroups7x13',updateStudentGroups7x13);
app.use('/updateRoom7x13',updateRoom7x13);
//7x13
app.use('/selectTimetable',selectTimetable);
app.use('/selectTimetableR',selectTimetableR);
app.use('/selectTimetableRR',selectTimetableRR);
app.use('/selectTimetableRRT',selectTimetableRRT);
app.use('/updateTimetable',updateTimetable);
app.use('/deleteTimetable',deleteTimetable);
//upload
app.use('/uploadCourse',uploadCourse);
//manage timetable
app.use('/yearByGroups',yearByGroups);
app.use('/termByYear',termByYear);
app.use('/subjectByTerm',subjectByTerm);
app.use('/subjectByTermD',subjectByTermD);
app.use('/teacherBySubject',teacherBySubject);


// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
