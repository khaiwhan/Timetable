var express = require('express');
var router = express.Router();
var Delete = require('../../models/delete');

router.delete('/:id', function (req, res, next) {
    var data = req.params.id
    Delete.deleteRoom(data, function (err, row) {

        if (err) {
            res.json(err);
            console.log("err")
        }
        else {
            res.json(row);
            console.log("suc")
        }
    })
});
module.exports = router;