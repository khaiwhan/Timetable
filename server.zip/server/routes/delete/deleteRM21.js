var express = require('express');
var router = express.Router();
var Delete = require('../../models/delete');

router.delete('/:sid/:gid/:tid/:yid', function (req, res, next) {
    var subject_id = req.params.sid
    var student_groups_id = req.params.gid
    var term_id = req.params.tid
    var year_id = req.params.yid
    Delete.deleteRM21(subject_id, student_groups_id, term_id, year_id, function (err, row) {

        if (err) {
            res.json(err);
            console.log("err")
        }
        else {
            res.json(row);
            console.log("suc")
        }
    })
});
module.exports = router;