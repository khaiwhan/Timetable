var express = require('express');
var router = express.Router();
var Select = require('../../models/select');

router.get('/:tid/:yid/:gid', function (req, res, next) {
    var term_id = req.params.tid
    var year_id = req.params.yid
    var student_groups_id = req.params.gid
    Select.subjectByTermD(term_id, year_id, student_groups_id, function (err, row) {

        if (err) {
            res.json(err);
            console.log("err")
        }
        else {
            res.json(row);
            console.log("suc")
        }
    })
});


module.exports = router;