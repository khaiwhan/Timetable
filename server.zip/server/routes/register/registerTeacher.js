var express = require('express');
var router = express.Router();
var Register = require('../../models/register');

router.post('/', function (req, res, next) {
    var data = req.body
    Register.registerTeacher(data, function (err, row) {

        if (err) {
            res.json(err);
            console.log("err")
        }
        else {
            res.json(row);
            console.log("suc")
        }
    })
});
module.exports = router;