var express = require('express');
var router = express.Router();
var Upload = require('../../models/upload');

router.post('/', function (req, res, next) {
    var data = req.body.data
    var course_id = req.body.course_id
    const result = {
        succ: [],
        err:[]
    }
    for (let list of data) {
        if (list.subject_id) {
            Upload.uploadCourse(list, course_id,function (err, row) {
                if (err) {
                    console.log(err)
                    result.err.push(err)
                }
                else {
                    console.log(row)
                    result.succ.push(row)

                }
            })
        }
    } 
    res.json(result)
});
module.exports = router;