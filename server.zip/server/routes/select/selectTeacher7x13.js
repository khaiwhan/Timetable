var express = require('express');
var router = express.Router();
var Select = require('../../models/select');

router.get('/:teid/:yid/:tid', function (req, res, next) {
    var teacher_id = req.params.teid
    var year_id = req.params.yid
    var term_id = req.params.tid
    Select.selectTeacher7x13(teacher_id, year_id, term_id, function (err, row) {

        if (err) {
            res.json(err);
            console.log("err")
        }
        else {
            res.json(row);
            console.log("suc")
        }
    })
});


module.exports = router;