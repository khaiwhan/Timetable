var express = require('express');
var router = express.Router();
var Select = require('../../models/select');

router.get('/:sid/:yid/:tid', function (req, res, next) {
    var student_groups_id = req.params.sid
    var year_id = req.params.yid
    var term_id = req.params.tid
    Select.selectStudentGroups7x13(student_groups_id,year_id,term_id, function (err, row) {

        if (err) {
            res.json(err);
            console.log("err")
        }
        else {
            res.json(row);
            console.log("suc")
        }
    })
});


module.exports = router;