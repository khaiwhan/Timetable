var express = require('express');
var router = express.Router();
var Select = require('../../models/select');

router.get('/', function (req, res, next) {
    var data = req.params
    Select.selectSubjectTeacher(data, function (err, row) {

        if (err) {
            res.json(err);
            console.log("err")
        }
        else {
            res.json(row);
            console.log("suc")
        }
    })
});
module.exports = router;