var express = require('express');
var router = express.Router();
var Select = require('../../models/select');

router.get('/:tid/:yid', function (req, res, next) {
    var term_id = req.params.tid
    var year_id = req.params.yid
    console.log(term_id, year_id)
    Select.viewTimetable(term_id, year_id,  function (err, row) {

        if (err) {
            res.json(err);
            console.log("err")
        }
        else {
            res.json(row);
            console.log("suc")
        }
    })
});
module.exports = router;