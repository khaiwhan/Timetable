var express = require('express');
var router = express.Router();
var Add = require('../../models/add');

router.post('/', function (req, res, next) {
    var data = req.body.data
    var course_id = req.body.course_id
    Add.addSubject(data, course_id, function (err, row) {

        if (err) {
            res.json(err);
            console.log("err")
        }
        else {
            res.json(row);
            console.log("suc")
        }
    })
});
module.exports = router;