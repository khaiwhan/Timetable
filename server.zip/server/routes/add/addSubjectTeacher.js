var express = require('express');
var router = express.Router();
var Add = require('../../models/add');
var SelectCheck = require('../../models/select_check')

router.post('/', function (req, res, next) {
    var data = req.body
    SelectCheck.selectSubjectTeacher_C(data, (err , row)=>{
        if(err){
            res.json(err);
        }
        else if(row <= 0){
            Add.addSubjectTeacher(data ,(error,rows)=>{
                if(error){
                    res.json(error)
                }
                else{
                    res.json(rows)
                    console.log('เพิ่มข้อมูลแล้ว')
                }
            })
        }
        else{
            res.json(500,'ข้อมูลซ้ำ')
            console.log('ข้อมูลซ้ำ')
        }
    })

});
module.exports = router;