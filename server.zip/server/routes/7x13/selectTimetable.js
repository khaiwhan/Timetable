var express = require('express');
var router = express.Router();
var Update7x13 = require('../../models/update_timetable');

router.put('/', function (req, res, next) {
    var data = req.body
    Update7x13.selectTimetable(data, function (err, row) {

        if (err) {
            res.json(err);
            console.log("err")
        }
        else {
            res.json(row);
            console.log("suc")
        }
    })
});
module.exports = router;