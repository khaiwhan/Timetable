var express = require('express');
var router = express.Router();
var Login = require('../../models/login');

router.post('/', function (req, res) {
    var data = req.body
    Login.loginTeacher(data, function (err, row) {

        if (err) {
            res.json(err);
            console.log("err")
        }
        else if (row.length <= 0) {
            res.json(404, 'error')
        }
        else {
            res.json(row[0])
        }
    })
});
module.exports = router;